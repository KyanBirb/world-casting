package at.petrak.hexcasting.fabric.mixin;

import at.petrak.hexcasting.common.lib.HexAttributes;
import net.minecraft.class_1657;
import net.minecraft.class_5132;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1657.class)
public abstract class FabricPlayerMixin {
    // This is done rather than using FabricDefaultAttributeRegistry.register(EntityType.PLAYER, <attributes>) because
    // if multiple mods all try to use that method, whichever loads last will override the registered AttributeSupplier
    // for EntityType.PLAYER and the other mods' attributes won't get added to the player.
    @Inject(at = @At("RETURN"), method = "createAttributes")
    private static void hex$addAttributes(CallbackInfoReturnable<class_5132.class_5133> cir) {
        var out = cir.getReturnValue();
        out.method_26867(HexAttributes.GRID_ZOOM);
        out.method_26867(HexAttributes.SCRY_SIGHT);
        out.method_26867(HexAttributes.FEEBLE_MIND);
        out.method_26867(HexAttributes.MEDIA_CONSUMPTION_MODIFIER);
        out.method_26867(HexAttributes.AMBIT_RADIUS);
        out.method_26867(HexAttributes.SENTINEL_RADIUS);
    }
}