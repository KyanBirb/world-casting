package at.petrak.hexcasting.api.casting.iota;

import at.petrak.hexcasting.api.utils.HexUtils;
import at.petrak.hexcasting.common.lib.hex.HexIotaTypes;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_124;
import net.minecraft.class_2489;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public class DoubleIota extends Iota {
    public static final double TOLERANCE = 0.0001;
    private double value;

    public DoubleIota(double d) {
        super(() -> HexIotaTypes.DOUBLE);
        this.value = d;
    }

    public double getDouble() {
        return HexUtils.fixNAN(value);
    }

    @Override
    public boolean isTruthy() {
        return this.getDouble() != 0.0;
    }

    @Override
    public boolean toleratesOther(Iota that) {
        return typesMatch(this, that)
            && that instanceof DoubleIota dd
            && tolerates(this.getDouble(), dd.getDouble());
    }

    public static boolean tolerates(double a, double b) {
        return Math.abs(a - b) < TOLERANCE;
    }

    @Override
    public int hashCode() {
        return Double.hashCode(value);
    }

    @Override
    public class_2561 display() {
        return DoubleIota.display(value);
    }

    public static IotaType<DoubleIota> TYPE = new IotaType<>() {
        public static final MapCodec<DoubleIota> CODEC = Codec.DOUBLE
                .xmap(DoubleIota::new, DoubleIota::getDouble)
                .fieldOf("value");
        public static final class_9139<class_9129, DoubleIota> STREAM_CODEC =
                class_9135.field_48553.method_56432(DoubleIota::new, DoubleIota::getDouble).method_56439(buffer -> buffer);

        @Override
        public MapCodec<DoubleIota> codec() {
            return CODEC;
        }

        @Override
        public class_9139<class_9129, DoubleIota> streamCodec() {
            return STREAM_CODEC;
        }

        @Override
        public int color() {
            return 0xff_55ff55;
        }
    };

    public static DoubleIota deserialize(class_2520 tag) throws IllegalArgumentException {
        var dtag = HexUtils.downcast(tag, class_2489.field_21031);
        return new DoubleIota(dtag.getAsDouble());
    }

    public static class_2561 display(double d) {
        return class_2561.method_43470(String.format("%.2f", d)).method_27692(class_124.field_1060);
    }
}
