package ram.talia.hexal.eventhandlers;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import org.jetbrains.annotations.Nullable;
import ram.talia.hexal.api.casting.wisp.WispCastingManager;
import ram.talia.hexal.common.entities.BaseCastingWisp;

import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Manages a Map of player UUIDs to {@link WispCastingManager}s.
 */
public class WispCastingManagerEventHandler {
	private static final String TAG_CASTING_MANAGER = "hexal:casting_manager";
	private static final String TAG_SEON = "hexal:seon";

	private static final Map<UUID, WispCastingManager> castingManagers = new HashMap<>();
	private static final Map<UUID, UUID> seonUUIDs = new HashMap<>();
	private static final Map<UUID, WeakReference<BaseCastingWisp>> seons = new HashMap<>();

	public static WispCastingManager getCastingManager(ServerPlayer serverPlayer) {
		WispCastingManager manager = castingManagers.get(serverPlayer.getUUID());
		if (manager == null) {
			manager = loadCastingManager(serverPlayer);
			castingManagers.put(serverPlayer.getUUID(), manager);
		}
		return manager;
	}
	
	private static WispCastingManager loadCastingManager(ServerPlayer player) {
		WispCastingManager manager = new WispCastingManager(player);
		manager.readFromNbt(player.getPersistentData().getCompound(TAG_CASTING_MANAGER), player.serverLevel());
		return manager;
	}

	public static @Nullable BaseCastingWisp getSeon(ServerPlayer player) {
		var ref = seons.get(player.getUUID());
		if (ref == null) {
			return refreshSeonFromLevel(player);
		}

		return ref.get();
	}

	public static void setSeon(ServerPlayer player, @Nullable BaseCastingWisp wisp) {
		var oldRef = seons.get(player.getUUID());
		// make the old seon no longer seon if it exists.
		if (oldRef == null) {
			var oldSeon = refreshSeonFromLevel(player);
			if (oldSeon != null) {
				oldSeon.setSeon(false);
			}
		} else {
			var oldSeon = oldRef.get();
			if (oldSeon != null)
				oldSeon.setSeon(false);
		}

		// make the new wisp seon if it exists.
		if (wisp != null) {
			wisp.setSeon(true);
			seonUUIDs.put(player.getUUID(), wisp.getUUID());
			seons.put(player.getUUID(), new WeakReference<>(wisp));
		} else {
			seonUUIDs.remove(player.getUUID());
			seons.remove(player.getUUID());
		}
	}

	private static void loadSeon(ServerPlayer player) {
		if (!player.getPersistentData().hasUUID(TAG_SEON))
			return;

		var seonUUID = player.getPersistentData().getUUID(TAG_SEON);

		var entity = player.serverLevel().getEntity(seonUUID);
		if (entity == null) {
			seonUUIDs.put(player.getUUID(), seonUUID);
			return;
		}

		if (entity instanceof BaseCastingWisp seon) {
			seonUUIDs.put(player.getUUID(), seonUUID);
			seons.put(player.getUUID(), new WeakReference<>(seon));
		}
	}

	private static @Nullable BaseCastingWisp refreshSeonFromLevel(ServerPlayer player) {
		var seonUUID = seonUUIDs.get(player.getUUID());
		if (seonUUID == null)
			return null;
		var entity = player.serverLevel().getEntity(seonUUID);

		if (!(entity instanceof BaseCastingWisp seon))
			return null;

		seons.put(player.getUUID(), new WeakReference<>(seon));
		return seon;
	}

	/**
	 * Creates a {@link WispCastingManager} for each player, and loads saved data for said casting manager if saved data exists.
	 */
	public static void playerLoggedIn(net.neoforged.neoforge.event.entity.player.PlayerEvent.PlayerLoggedInEvent event) {
		if (event.getEntity().level().isClientSide())
			return;
		
		ServerPlayer player = (ServerPlayer) event.getEntity();

		castingManagers.put(player.getUUID(), loadCastingManager(player));
		loadSeon(player);
	}
	
	/**
	 * Save each player's {@link WispCastingManager} so that casts which haven't resolved yet will
	 * resolve when the player logs back in.
	 */
	public static void playerLoggedOut(PlayerEvent.PlayerLoggedOutEvent event) {
		if (event.getEntity().level().isClientSide())
			return;
		
		ServerPlayer player = (ServerPlayer) event.getEntity();
		
		CompoundTag tag = new CompoundTag();
		getCastingManager(player).writeToNbt(tag);
		
		player.getPersistentData().put(TAG_CASTING_MANAGER, tag);
		var seonUUID = seonUUIDs.get(player.getUUID());
		if (seonUUID != null) {
			player.getPersistentData().putUUID(TAG_SEON, seonUUID);
		}

		castingManagers.remove(player.getUUID());
		seonUUIDs.remove(player.getUUID());
		seons.remove(player.getUUID());
	}

    public static void serverTick(PlayerTickEvent.Pre event) {
        Player player = event.getEntity();
		if (player.level().isClientSide) {
			return;
		}
		ServerPlayer serverPlayer = (ServerPlayer) player;
		getCastingManager(serverPlayer).executeCasts();
    }
}
