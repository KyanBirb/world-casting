package ram.talia.hexal.common.casting.actions.spells

import at.petrak.hexcasting.api.casting.ParticleSpray
import at.petrak.hexcasting.api.casting.RenderedSpell
import at.petrak.hexcasting.api.casting.castables.SpellAction
import at.petrak.hexcasting.api.casting.eval.CastingEnvironment
import at.petrak.hexcasting.api.casting.getVec3
import at.petrak.hexcasting.api.casting.iota.Iota
import at.petrak.hexcasting.api.mod.HexConfig
import at.petrak.hexcasting.api.utils.isCorrectTierForDrops
import at.petrak.hexcasting.xplat.IXplatAbstractions
import net.minecraft.core.BlockPos
import net.minecraft.core.particles.BlockParticleOption
import net.minecraft.core.particles.ParticleTypes
import net.minecraft.core.registries.Registries
import net.minecraft.server.level.ServerLevel
import net.minecraft.server.level.ServerPlayer
import net.minecraft.tags.BlockTags
import net.minecraft.world.entity.Entity
import net.minecraft.world.entity.item.FallingBlockEntity
import net.minecraft.world.item.Item
import net.minecraft.world.item.ItemStack
import net.minecraft.world.item.Items
import net.minecraft.world.item.Tier
import net.minecraft.world.item.enchantment.Enchantments
import net.minecraft.world.level.block.Block
import net.minecraft.world.level.block.FallingBlock
import net.minecraft.world.level.block.state.BlockState
import net.minecraft.world.phys.Vec3
import ram.talia.hexal.api.config.HexalConfig
import kotlin.math.min

// https://github.com/VazkiiMods/Botania/blob/1.19.x/Xplat/src/main/java/vazkii/botania/common/item/lens/LensWeight.java
object OpFallingBlock : SpellAction {
	override val argc = 1

	override fun execute(args: List<Iota>, env: CastingEnvironment): SpellAction.Result {
		val pos = args.getVec3(0, argc)
		env.assertVecInRange(pos)

		val centered = Vec3.atCenterOf(BlockPos.containing(pos))
		return SpellAction.Result(
			Spell(pos),
			(HexalConfig.Server.FALLING_BLOCK_COST.get() * 10000.0).toLong(),
			listOf(ParticleSpray.burst(centered, 1.0))
		)
	}

	private data class Spell(val v: Vec3) : RenderedSpell {
		override fun cast(env: CastingEnvironment) {
			val pos = BlockPos.containing(v)

			val blockstate = env.world.getBlockState(pos)
			if (!env.canEditBlockAt(pos) || !IXplatAbstractions.INSTANCE.isBreakingAllowed(env.world, pos, blockstate, env.castingEntity as? ServerPlayer))
				return

			val tier : Tier = HexConfig.server().opBreakHarvestLevel()

			val stateBelow = env.world.getBlockState(pos.below())

			if ((
					FallingBlock.isFree(stateBelow)
					|| !stateBelow.canOcclude()
					|| stateBelow.`is`(BlockTags.SLABS)
				)
				&& !blockstate.isAir
				&& blockstate.getDestroySpeed(env.world, pos) >= 0f // fix being able to break bedrock &c
				&& env.world.getBlockEntity(pos) == null
				&& isCorrectTierForDrops(tier, blockstate)
				&& canSilkTouch(env.world, pos, blockstate, tier.attackDamageBonus.toInt(), env.castingEntity)
			) {
				val falling: FallingBlockEntity = FallingBlockEntity.fall(env.world, pos, blockstate)
				falling.time = 1
				env.world.sendParticles(
					BlockParticleOption(ParticleTypes.FALLING_DUST, blockstate),
					pos.x + 0.5,
					pos.y + 0.5,
					pos.z + 0.5,
					10,
					0.45,
					0.45,
					0.45,
					5.0
				)
			}
		}

		fun canSilkTouch(level: ServerLevel, pos: BlockPos, state: BlockState, harvestLevel: Int, owner: Entity?): Boolean {
			val harvestToolStack: ItemStack = getHarvestToolStack(harvestLevel, state)
			if (harvestToolStack.isEmpty) {
				return false
			}
			// I'm not sure how to fix this, so this is temporarily broken.
			//harvestToolStack.enchant(Enchantments.SILK_TOUCH,1)
			val silkTouch = level.registryAccess()
				.lookupOrThrow(Registries.ENCHANTMENT)
				.getOrThrow(Enchantments.SILK_TOUCH)
			harvestToolStack.enchant(silkTouch, 1)

			val drops: List<ItemStack> = Block.getDrops(state, level, pos, null, owner, harvestToolStack)
			val blockItem: Item = state.block.asItem()
			return drops.any { s -> s.item === blockItem }
		}

		companion object {
			fun getHarvestToolStack(harvestLevel: Int, state: BlockState): ItemStack {
				return getTool(harvestLevel, state).copy()
			}

			private fun getTool(harvestLevel: Int, state: BlockState): ItemStack {
				val idx = min(harvestLevel, HARVEST_TOOLS_BY_LEVEL.size - 1)
				if (!state.requiresCorrectToolForDrops()) {
					return HARVEST_TOOLS_BY_LEVEL[idx][0]
				}
				for (tool in HARVEST_TOOLS_BY_LEVEL[idx]) {
					if (tool.isCorrectToolForDrops(state)) {
						return tool
					}
				}
				return ItemStack.EMPTY
			}

			private val HARVEST_TOOLS_BY_LEVEL: List<List<ItemStack>> = listOf(
				stacks(Items.WOODEN_PICKAXE, Items.WOODEN_AXE, Items.WOODEN_HOE, Items.WOODEN_SHOVEL),
				stacks(Items.STONE_PICKAXE, Items.STONE_AXE, Items.STONE_HOE, Items.STONE_SHOVEL),
				stacks(Items.IRON_PICKAXE, Items.IRON_AXE, Items.IRON_HOE, Items.IRON_SHOVEL),
				stacks(Items.DIAMOND_PICKAXE, Items.DIAMOND_AXE, Items.DIAMOND_HOE, Items.DIAMOND_SHOVEL),
				stacks(Items.NETHERITE_PICKAXE, Items.NETHERITE_AXE, Items.NETHERITE_HOE, Items.NETHERITE_SHOVEL)
			)

			private fun stacks(vararg items: Item): List<ItemStack> {
				return items.map { item -> ItemStack(item) }
			}
		}
	}
}
