package ram.talia.hexal.api.casting.wisp.triggers

import at.petrak.hexcasting.api.casting.eval.CastingEnvironment
import at.petrak.hexcasting.api.casting.getLong
import at.petrak.hexcasting.api.casting.iota.Iota
import at.petrak.hexcasting.api.utils.asLong
import net.minecraft.nbt.ByteTag
import net.minecraft.nbt.LongTag
import net.minecraft.nbt.Tag
import net.minecraft.server.level.ServerLevel
import ram.talia.hexal.Hexal
import ram.talia.hexal.common.entities.BaseCastingWisp
import ram.talia.hexal.common.entities.TickingWisp

object WispTriggerTypes {
	@JvmField
	val TICK_TRIGGER_TYPE = object : WispTriggerRegistry.WispTriggerType<TickTrigger>(Hexal.modLoc("trigger/tick")) {
		override val argc = 1

		override fun makeFromArgs(wisp: BaseCastingWisp, args: List<Iota>, env: CastingEnvironment): TickTrigger {
			val count = args.getLong(0, argc)

			return TickTrigger(count + env.world.gameTime)
		}

		override fun fromNbt(tag: Tag, level: ServerLevel) = TickTrigger.readFromNbt(tag, level)
	}

	@JvmField
	val MOVE_TRIGGER_TYPE = object : WispTriggerRegistry.WispTriggerType<MoveTrigger>(Hexal.modLoc("trigger/move")) {
		override val argc = 0

		override fun makeFromArgs(wisp: BaseCastingWisp, args: List<Iota>, env: CastingEnvironment) = MoveTrigger()

		override fun fromNbt(tag: Tag, level: ServerLevel) = MoveTrigger.readFromNbt(tag, level)
	}
}

data class TickTrigger(val tick: Long) : IWispTrigger {
	override var hasTriggered = false

	override fun shouldTrigger(wisp: BaseCastingWisp): Boolean {

		if (wisp.level().gameTime < tick)
			return false

		hasTriggered = true
		return true
	}

	override fun getTriggerType() = WispTriggerTypes.TICK_TRIGGER_TYPE

	override fun writeToNbt() = LongTag.valueOf(tick)

	companion object {
		fun readFromNbt(tag: Tag, level: ServerLevel) = TickTrigger(tag.asLong)
	}
}

class MoveTrigger : IWispTrigger {
	override var hasTriggered = false

	override fun shouldTrigger(wisp: BaseCastingWisp): Boolean {
		if (wisp !is TickingWisp || !wisp.reachedTargetPos())
			return false

		hasTriggered = true
		return true
	}

	override fun getTriggerType() = WispTriggerTypes.MOVE_TRIGGER_TYPE

	override fun writeToNbt() = ByteTag.ZERO

	companion object {
		fun readFromNbt(tag: Tag, level: ServerLevel) = MoveTrigger()
	}
}