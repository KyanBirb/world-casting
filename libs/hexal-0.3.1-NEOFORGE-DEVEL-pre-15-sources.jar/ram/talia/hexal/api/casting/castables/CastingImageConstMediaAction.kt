package ram.talia.hexal.api.casting.castables

import at.petrak.hexcasting.api.casting.castables.Action
import at.petrak.hexcasting.api.casting.castables.ConstMediaAction
import at.petrak.hexcasting.api.casting.eval.CastingEnvironment
import at.petrak.hexcasting.api.casting.eval.OperationResult
import at.petrak.hexcasting.api.casting.eval.sideeffects.OperatorSideEffect
import at.petrak.hexcasting.api.casting.eval.vm.CastingImage
import at.petrak.hexcasting.api.casting.eval.vm.SpellContinuation
import at.petrak.hexcasting.api.casting.iota.Iota
import at.petrak.hexcasting.api.casting.mishaps.MishapNotEnoughArgs
import at.petrak.hexcasting.api.casting.mishaps.MishapNotEnoughMedia
import at.petrak.hexcasting.common.lib.hex.HexEvalSounds
import net.minecraft.nbt.CompoundTag

/**
 * A SimpleOperator that always costs the same amount of media. Provides access to the CastingImage.
 */
interface CastingImageConstMediaAction : Action {
    val argc: Int
    val mediaCost: Long
        get() = 0

    fun execute(args: List<Iota>, image: CastingImage, env: CastingEnvironment): List<Iota>

    fun executeWithOpCount(args: List<Iota>, image: CastingImage, env: CastingEnvironment): ConstMediaAction.CostMediaActionResult {
        val stack = this.execute(args, image, env)
        return ConstMediaAction.CostMediaActionResult(stack)
    }

    override fun operate(env: CastingEnvironment, image: CastingImage, continuation: SpellContinuation): OperationResult {
        var stack = image.stack

        if (env.extractMedia(this.mediaCost, true) > 0) {
            throw MishapNotEnoughMedia(this.mediaCost)
        }
        if (this.argc > stack.size)
            throw MishapNotEnoughArgs(this.argc, stack.size)
        val args = stack.takeRight(argc)
        stack = stack.dropRight(argc);
        val result = executeWithOpCount(args, image, env)

        val sideEffects = mutableListOf<OperatorSideEffect>(OperatorSideEffect.ConsumeMedia(this.mediaCost))

        val image2 = image.copy(stack = stack.appendedAll(result.resultStack), opsConsumed = image.opsConsumed + result.opCount)
        return OperationResult(image2, sideEffects, continuation, HexEvalSounds.NORMAL_EXECUTE.get())
    }
}