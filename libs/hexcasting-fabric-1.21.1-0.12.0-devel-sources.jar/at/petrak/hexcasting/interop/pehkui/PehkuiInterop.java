package at.petrak.hexcasting.interop.pehkui;

import at.petrak.hexcasting.interop.HexInterop;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import net.minecraft.class_1297;

public class PehkuiInterop {
    public static void init() {
        // for future work
    }

    public static boolean isActive() {
        return IXplatAbstractions.INSTANCE.isModPresent(HexInterop.PEHKUI_ID);
    }

    /**
     * Pehkui doesn't publish an API jar so we do this BS
     */
    public interface ApiAbstraction {
        float getScale(class_1297 e);

        void setScale(class_1297 e, float scale);
    }
}
