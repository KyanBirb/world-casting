package at.petrak.hexcasting.interop.utils;

import at.petrak.hexcasting.api.misc.MediaConstants;
import at.petrak.hexcasting.api.mod.HexConfig;
import at.petrak.hexcasting.common.items.magic.ItemMediaBattery;
import at.petrak.hexcasting.common.lib.HexBlocks;
import at.petrak.hexcasting.common.lib.HexItems;
import com.google.common.collect.Lists;
import com.mojang.datafixers.util.Pair;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

public class PhialRecipeStackBuilder {
    private static class_1799 makeBattery(long unit, int size) {
        return ItemMediaBattery.withMedia(new class_1799(HexItems.BATTERY), unit * size, unit * size);
    }

    public static Pair<List<class_1799>, List<class_1799>> createStacks() {
        List<class_1799> inputItems = Lists.newArrayList();
        List<class_1799> outputItems = Lists.newArrayList();

        long dust = HexConfig.common().dustMediaAmount();
        long shard = HexConfig.common().shardMediaAmount();
        long charged = HexConfig.common().chargedCrystalMediaAmount();
        long quenchedShard = MediaConstants.QUENCHED_SHARD_UNIT;
        long quenchedBlock = MediaConstants.QUENCHED_BLOCK_UNIT;


        if (dust > 0) {
            inputItems.add(new class_1799(HexItems.AMETHYST_DUST, 1));
            outputItems.add(makeBattery(dust, 1));
            inputItems.add(new class_1799(HexItems.AMETHYST_DUST, 64));
            outputItems.add(makeBattery(dust, 64));
        }

        if (shard > 0) {
            inputItems.add(new class_1799(class_1802.field_27063, 1));
            outputItems.add(makeBattery(shard, 1));
            inputItems.add(new class_1799(class_1802.field_27063, 64));
            outputItems.add(makeBattery(shard, 64));
        }

        if (charged > 0) {
            inputItems.add(new class_1799(HexItems.CHARGED_AMETHYST, 1));
            outputItems.add(makeBattery(charged, 1));
            inputItems.add(new class_1799(HexItems.CHARGED_AMETHYST, 64));
            outputItems.add(makeBattery(charged, 64));
        }

        inputItems.add(new class_1799(HexItems.QUENCHED_SHARD, 1));
        outputItems.add(makeBattery(quenchedShard, 1));
        inputItems.add(new class_1799(HexItems.QUENCHED_SHARD, 64));
        outputItems.add(makeBattery(quenchedShard, 64));

        inputItems.add(new class_1799(HexBlocks.QUENCHED_ALLAY, 1));
        outputItems.add(makeBattery(quenchedBlock, 1));
        inputItems.add(new class_1799(HexBlocks.QUENCHED_ALLAY, 64));
        outputItems.add(makeBattery(quenchedBlock, 64));

        return new Pair<>(inputItems, outputItems);
    }

    public static boolean shouldAddRecipe() {
        return HexConfig.common().dustMediaAmount() > 0 ||
            HexConfig.common().shardMediaAmount() > 0 ||
            HexConfig.common().chargedCrystalMediaAmount() > 0;
    }
}
