package at.petrak.hexcasting.interop.utils;

import at.petrak.hexcasting.api.casting.math.HexCoord;
import at.petrak.hexcasting.api.casting.math.HexPattern;
import java.util.List;
import net.minecraft.class_241;

public record PatternEntry(HexPattern pattern, HexCoord origin, List<class_241> zappyPoints) {
    // NO-OP
}
