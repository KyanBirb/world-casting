package at.petrak.hexcasting.fabric.xplat;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.api.addldata.ADHexHolder;
import at.petrak.hexcasting.api.addldata.ADIotaHolder;
import at.petrak.hexcasting.api.addldata.ADMediaHolder;
import at.petrak.hexcasting.api.addldata.ADVariantItem;
import at.petrak.hexcasting.api.casting.ActionRegistryEntry;
import at.petrak.hexcasting.api.casting.arithmetic.Arithmetic;
import at.petrak.hexcasting.api.casting.castables.SpecialHandler;
import at.petrak.hexcasting.api.casting.eval.ResolvedPattern;
import at.petrak.hexcasting.api.casting.eval.sideeffects.EvalSound;
import at.petrak.hexcasting.api.casting.eval.vm.CastingImage;
import at.petrak.hexcasting.api.casting.eval.vm.CastingVM;
import at.petrak.hexcasting.api.casting.eval.vm.ContinuationFrame;
import at.petrak.hexcasting.api.casting.iota.IotaType;
import at.petrak.hexcasting.api.mod.HexConfig;
import at.petrak.hexcasting.api.mod.HexTags;
import at.petrak.hexcasting.api.pigment.ColorProvider;
import at.petrak.hexcasting.api.pigment.FrozenPigment;
import at.petrak.hexcasting.api.player.AltioraAbility;
import at.petrak.hexcasting.api.player.FlightAbility;
import at.petrak.hexcasting.api.player.Sentinel;
import at.petrak.hexcasting.common.lib.HexRegistries;
import at.petrak.hexcasting.common.recipe.ingredient.brainsweep.BrainsweepeeIngredientType;
import at.petrak.hexcasting.common.recipe.ingredient.state.StateIngredientType;
import at.petrak.hexcasting.fabric.cc.HexCardinalComponents;
import at.petrak.hexcasting.fabric.interop.accessories.AccessoriesApiInterop;
import at.petrak.hexcasting.fabric.recipe.FabricUnsealedIngredient;
import at.petrak.hexcasting.interop.HexInterop;
import at.petrak.hexcasting.interop.pehkui.PehkuiInterop;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import at.petrak.hexcasting.xplat.IXplatRegister;
import at.petrak.hexcasting.xplat.IXplatTags;
import at.petrak.hexcasting.xplat.Platform;
import com.google.common.base.Suppliers;
import com.mojang.serialization.Lifecycle;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.entity.FakePlayer;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.event.registry.FabricRegistryBuilder;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidStorage;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1832;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.minecraft.class_2073;
import net.minecraft.class_223;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2348;
import net.minecraft.class_2350;
import net.minecraft.class_2370;
import net.minecraft.class_2378;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3611;
import net.minecraft.class_5321;
import net.minecraft.class_5341;
import net.minecraft.class_6862;
import net.minecraft.class_8551;
import net.minecraft.class_8710;
import net.minecraft.core.*;
import org.jetbrains.annotations.Nullable;
import virtuoel.pehkui.api.ScaleTypes;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.function.Supplier;
import java.util.stream.Stream;

public class FabricXplatImpl implements IXplatAbstractions {
    @Override
    public Platform platform() {
        return Platform.FABRIC;
    }

    @Override
    public boolean isPhysicalClient() {
        return FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT;
    }

    @Override
    public boolean isModPresent(String id) {
        return FabricLoader.getInstance().isModLoaded(id);
    }

    @Override
    public void initPlatformSpecific() {
        if (this.isModPresent(HexInterop.Fabric.ACCESSORIES_API_ID)) {
            AccessoriesApiInterop.init();
        }
    }

//    @Override
//    public double getReachDistance(Player player) {
//        return ReachEntityAttributes.getReachDistance(player, 5.0);
//    }

    @Override
    public void sendPacketToPlayer(class_3222 target, class_8710 packet) {
        ServerPlayNetworking.send(target, packet);
    }

    @Override
    public void sendPacketNear(class_243 pos, double radius, class_3218 dimension, class_8710 packet) {
        sendPacketToPlayers(PlayerLookup.around(dimension, pos, radius), packet);
    }

    @Override
    public void sendPacketTracking(class_1297 entity, class_8710 packet) {
        sendPacketToPlayers(PlayerLookup.tracking(entity), packet);
    }

    private void sendPacketToPlayers(Collection<class_3222> players, class_8710 packet) {
        var pkt = ServerPlayNetworking.createS2CPacket(packet);
        for (var p : players) {
            p.field_13987.method_14364(pkt);
        }
    }

    @Override
    public class_2596<class_2602> toVanillaClientboundPacket(class_8710 message) {
        return (class_2596<class_2602>) (Object) ServerPlayNetworking.createS2CPacket(message);
    }

    @Override
    public void setBrainsweepAddlData(class_1308 mob) {
        var cc = HexCardinalComponents.BRAINSWEPT.get(mob);
        cc.setBrainswept(true);
        // CC API does the syncing for us
    }

    @Override
    public @Nullable FrozenPigment setPigment(class_1657 target, @Nullable FrozenPigment pigment) {
        var cc = HexCardinalComponents.FAVORED_PIGMENT.get(target);
        var old = cc.getPigment();
        cc.setPigment(pigment);
        return old;
    }

    @Override
    public void setSentinel(class_1657 target, @Nullable Sentinel sentinel) {
        var cc = HexCardinalComponents.SENTINEL.get(target);
        cc.setSentinel(sentinel);
    }

    @Override
    public void setFlight(class_3222 target, FlightAbility flight) {
        var cc = HexCardinalComponents.FLIGHT.get(target);
        cc.setFlight(flight);
    }

    public void setAltiora(class_1657 target, @Nullable AltioraAbility altiora) {
        var cc = HexCardinalComponents.ALTIORA.get(target);
        cc.setAltiora(altiora);
    }

    public void setStaffcastImage(class_3222 target, CastingImage image) {
        var cc = HexCardinalComponents.STAFFCAST_IMAGE.get(target);
        cc.setImage(image);
    }

    @Override
    public void setPatterns(class_3222 target, List<ResolvedPattern> patterns) {
        var cc = HexCardinalComponents.PATTERNS.get(target);
        cc.setPatterns(patterns);
    }

    @Override
    public boolean isBrainswept(class_1308 mob) {
        var cc = HexCardinalComponents.BRAINSWEPT.get(mob);
        return cc.isBrainswept();
    }

    @Override
    public @Nullable FlightAbility getFlight(class_3222 player) {
        var cc = HexCardinalComponents.FLIGHT.get(player);
        return cc.getFlight();
    }

    @Override
    public @Nullable AltioraAbility getAltiora(class_1657 player) {
        var cc = HexCardinalComponents.ALTIORA.get(player);
        return cc.getAltiora();
    }

    @Override
    public FrozenPigment getPigment(class_1657 player) {
        var cc = HexCardinalComponents.FAVORED_PIGMENT.get(player);
        return cc.getPigment();
    }

    @Override
    public Sentinel getSentinel(class_1657 player) {
        var cc = HexCardinalComponents.SENTINEL.get(player);
        return cc.getSentinel();
    }

    @Override
    public CastingVM getStaffcastVM(class_3222 player, class_1268 hand) {
        var cc = HexCardinalComponents.STAFFCAST_IMAGE.get(player);
        return cc.getVM(hand);
    }

    @Override
    public List<ResolvedPattern> getPatternsSavedInUi(class_3222 player) {
        var cc = HexCardinalComponents.PATTERNS.get(player);
        return cc.getPatterns();
    }

    @Override
    public void clearCastingData(class_3222 player) {
        this.setStaffcastImage(player, null);
        this.setPatterns(player, List.of());
    }

    @Override
    public @Nullable
    ADMediaHolder findMediaHolder(class_1799 stack) {
        return HexCardinalComponents.MEDIA_HOLDER_LOOKUP.find(stack, null);
    }

    @Override
    public @Nullable
    ADIotaHolder findDataHolder(class_1799 stack) {
        return HexCardinalComponents.IOTA_HOLDER_LOOKUP.find(stack, null);
    }

    @Override
    public @Nullable
    ADIotaHolder findDataHolder(class_1297 entity) {
        var cc = HexCardinalComponents.IOTA_HOLDER.maybeGet(entity);
        return cc.orElse(null);
    }

    @Override
    public @Nullable
    ADHexHolder findHexHolder(class_1799 stack) {
        return HexCardinalComponents.HEX_HOLDER_LOOKUP.find(stack, null);
    }

    @Override
    public ADVariantItem findVariantHolder(class_1799 stack) {
        return HexCardinalComponents.VARIANT_ITEM_LOOKUP.find(stack, null);
    }

    @Override
    public boolean isPigment(class_1799 stack) {
        return HexCardinalComponents.PIGMENT_ITEM_LOOKUP.find(stack, null) != null;
    }

    @Override
    public ColorProvider getColorProvider(FrozenPigment pigment) {
        var cc = Optional.ofNullable(HexCardinalComponents.PIGMENT_ITEM_LOOKUP.find(pigment.item(), null));
        return cc.map(col -> col.provideColor(pigment.owner())).orElse(ColorProvider.MISSING);
    }

    @Override
    public <T extends class_2586> class_2591<T> createBlockEntityType(BiFunction<class_2338, class_2680, T> func,
        class_2248... blocks) {
        return FabricBlockEntityTypeBuilder.create(func::apply, blocks).build();
    }

    @Override
    @SuppressWarnings("UnstableApiUsage")
    public boolean tryPlaceFluid(class_1937 level, class_1268 hand, class_2338 pos, class_3611 fluid) {
        Storage<FluidVariant> target = FluidStorage.SIDED.find(level, pos, class_2350.field_11036);
        if (target == null) {
            return false;
        }
        try (Transaction transaction = Transaction.openOuter()) {
            long insertedAmount = target.insert(FluidVariant.of(fluid), FluidConstants.BUCKET, transaction);
            if (insertedAmount > 0) {
                transaction.commit();
                return true;
            }
        }
        return false;
    }

    @Override
    @SuppressWarnings("UnstableApiUsage")
    public boolean drainAllFluid(class_1937 level, class_2338 pos) {
        Storage<FluidVariant> target = FluidStorage.SIDED.find(level, pos, class_2350.field_11036);
        if (target == null) {
            return false;
        }
        try (Transaction transaction = Transaction.openOuter()) {
            boolean any = false;
            for (var view : target) {
                long extracted = view.extract(view.getResource(), view.getAmount(), transaction);
                if (extracted > 0) {
                    any = true;
                }
            }

            if (any) {
                transaction.commit();
                return true;
            }
        }
        return false;
    }

    @Override
    public class_1856 getUnsealedIngredient(class_1799 stack) {
        return FabricUnsealedIngredient.of(stack);
    }

    // do a stupid hack from botania
    private static List<class_1799> stacks(class_1792... items) {
        return Stream.of(items).map(class_1799::new).toList();
    }

    private static final List<List<class_1799>> HARVEST_TOOLS_BY_LEVEL = List.of(
        stacks(class_1802.field_8647, class_1802.field_8406, class_1802.field_8167, class_1802.field_8876),
        stacks(class_1802.field_8387, class_1802.field_8062, class_1802.field_8431, class_1802.field_8776),
        stacks(class_1802.field_8403, class_1802.field_8475, class_1802.field_8609, class_1802.field_8699),
        stacks(class_1802.field_8377, class_1802.field_8556, class_1802.field_8527, class_1802.field_8250),
        stacks(class_1802.field_22024, class_1802.field_22025, class_1802.field_22026, class_1802.field_22023)
    );

    @Override
    public boolean isCorrectTierForDrops(class_1832 tier, class_2680 bs) {
        if (!bs.method_29291()) {
            return true;
        }

        int level = HexConfig.server()
            .opBreakHarvestLevelBecauseForgeThoughtItWasAGoodIdeaToImplementHarvestTiersUsingAnHonestToGodTopoSort();
        for (var tool : HARVEST_TOOLS_BY_LEVEL.get(level)) {
            if (tool.method_7951(bs)) {
                return true;
            }
        }

        return false;
    }

    @Override
    public class_1792.class_1793 addEquipSlotFabric(class_1304 slot) {
        return new class_1792.class_1793().equipmentSlot((e, s) -> slot);
    }

    private static final IXplatTags TAGS = new IXplatTags() {
        @Override
        public class_6862<class_1792> amethystDust() {
            return HexTags.Items.create(class_2960.method_60655("c", "amethyst_dusts"));
        }

        @Override
        public class_6862<class_1792> gems() {
            return HexTags.Items.create(class_2960.method_60655("c", "gems"));
        }
    };

    @Override
    public IXplatTags tags() {
        return TAGS;
    }

    @Override
    public class_5341.class_210 isShearsCondition() {
        return class_8551.method_51727(
            class_223.method_945(class_2073.class_2074.method_8973().method_8977(class_1802.field_8868)),
            class_223.method_945(class_2073.class_2074.method_8973().method_8975(
                HexTags.Items.create(class_2960.method_60655("c", "shears"))))
        );
    }

    @Override
    public String getModName(String namespace) {
        if (namespace.equals("c")) {
            return "Common";
        }
        Optional<ModContainer> container = FabricLoader.getInstance().getModContainer(namespace);
        if (container.isPresent()) {
            return container.get().getMetadata().getName();
        }
        return namespace;
    }

    private static final Supplier<class_2378<ActionRegistryEntry>> ACTION_REGISTRY = Suppliers.memoize(() ->
        FabricRegistryBuilder.from(new class_2370<>(
                HexRegistries.ACTION,
                Lifecycle.stable()))
            .buildAndRegister()
    );
    private static final Supplier<class_2378<SpecialHandler.Factory<?>>> SPECIAL_HANDLER_REGISTRY =
        Suppliers.memoize(() ->
            FabricRegistryBuilder.from(new class_2370<>(
                    HexRegistries.SPECIAL_HANDLER,
                    Lifecycle.stable()))
                .buildAndRegister()
        );
    private static final Supplier<class_2378<IotaType<?>>> IOTA_TYPE_REGISTRY = Suppliers.memoize(() ->
        FabricRegistryBuilder.from(new class_2370<>(
                HexRegistries.IOTA_TYPE,
                Lifecycle.stable(), false))
            .buildAndRegister()
    );

    private static final Supplier<class_2378<Arithmetic>> ARITHMETIC_REGISTRY = Suppliers.memoize(() ->
            FabricRegistryBuilder.from(new class_2370<>(
                    HexRegistries.ARITHMETIC,
                    Lifecycle.stable()))
                .buildAndRegister()
    );

    private static final Supplier<class_2378<ContinuationFrame.Type<?>>> CONTINUATION_TYPE_REGISTRY = Suppliers.memoize(() ->
            FabricRegistryBuilder.from(new class_2348<>(
                            HexAPI.MOD_ID + ":end", HexRegistries.CONTINUATION_TYPE,
                            Lifecycle.stable(), false))
                    .buildAndRegister()
    );

    private static final Supplier<class_2378<EvalSound>> EVAL_SOUNDS_REGISTRY = Suppliers.memoize(() ->
        FabricRegistryBuilder.from(new class_2348<>(
                HexAPI.MOD_ID + ":nothing", HexRegistries.EVAL_SOUND,
                Lifecycle.stable(), false))
            .buildAndRegister()
    );

    private static final Supplier<class_2378<StateIngredientType<?>>> STATE_INGREDIENT_REGISTRY = Suppliers.memoize(() ->
            FabricRegistryBuilder.from(new class_2348<>(
                            HexAPI.MOD_ID + ":none",
                    HexRegistries.STATE_INGREDIENT,
                    Lifecycle.stable(), false))
                    .buildAndRegister()
    );

    private static final Supplier<class_2378<BrainsweepeeIngredientType<?>>> BRAINSWEEPEE_INGREDIENT_REGISTRY = Suppliers.memoize(() ->
            FabricRegistryBuilder.from(new class_2348<>(
                            HexAPI.MOD_ID + ":none",
                    HexRegistries.BRAINSWEEPEE_INGREDIENT,
                    Lifecycle.stable(), false))
                    .buildAndRegister()
    );

    @Override
    public class_2378<ActionRegistryEntry> getActionRegistry() {
        return ACTION_REGISTRY.get();
    }

    @Override
    public class_2378<SpecialHandler.Factory<?>> getSpecialHandlerRegistry() {
        return SPECIAL_HANDLER_REGISTRY.get();
    }

    @Override
    public class_2378<IotaType<?>> getIotaTypeRegistry() {
        return IOTA_TYPE_REGISTRY.get();
    }

    @Override
    public class_2378<Arithmetic> getArithmeticRegistry() {
        return ARITHMETIC_REGISTRY.get();
    }

    @Override
    public class_2378<ContinuationFrame.Type<?>> getContinuationTypeRegistry() {
        return CONTINUATION_TYPE_REGISTRY.get();
    }

    @Override
    public class_2378<EvalSound> getEvalSoundRegistry() {
        return EVAL_SOUNDS_REGISTRY.get();
    }

    @Override
    public class_2378<StateIngredientType<?>> getStateIngredientRegistry() {
        return STATE_INGREDIENT_REGISTRY.get();
    }

    @Override
    public class_2378<BrainsweepeeIngredientType<?>> getBrainsweepeeIngredientRegistry() {
        return BRAINSWEEPEE_INGREDIENT_REGISTRY.get();
    }

    @Override
    public boolean isBreakingAllowed(class_3218 world, class_2338 pos, class_2680 state, @Nullable class_1657 player) {
        if (player == null)
            player = FakePlayer.get(world, HEXCASTING);
        return PlayerBlockBreakEvents.BEFORE.invoker()
            .beforeBlockBreak(world, player, pos, state, world.method_8321(pos));
    }

    @Override
    public boolean isPlacingAllowed(class_3218 world, class_2338 pos, class_1799 blockStack, @Nullable class_1657 player) {
        if (player == null)
            player = FakePlayer.get(world, HEXCASTING);
        class_1799 cached = player.method_6047();
        player.method_6122(class_1268.field_5808, blockStack.method_7972());
        var success = UseItemCallback.EVENT.invoker().interact(player, world, class_1268.field_5808);
        player.method_6122(class_1268.field_5808, cached);
        return success.method_5467() == class_1269.field_5811; // No other mod tried to consume this
    }

    @Override
    public <B> IXplatRegister<B> createRegistar(class_5321<class_2378<B>> registryKey) {
        return new FabricRegister<>(registryKey);
    }

    private static PehkuiInterop.ApiAbstraction PEHKUI_API = null;

    @Override
    public PehkuiInterop.ApiAbstraction getPehkuiApi() {
        if (!this.isModPresent(HexInterop.PEHKUI_ID)) {
            throw new IllegalArgumentException("cannot get the pehkui api without pehkui");
        }

        if (PEHKUI_API == null) {
            PEHKUI_API = new PehkuiInterop.ApiAbstraction() {
                @Override
                public float getScale(class_1297 e) {
                    return ScaleTypes.BASE.getScaleData(e).getScale();
                }

                @Override
                public void setScale(class_1297 e, float scale) {
                    ScaleTypes.BASE.getScaleData(e).setScale(scale);
                }
            };
        }
        return PEHKUI_API;
    }

}
