package at.petrak.hexcasting.fabric.cc;

import at.petrak.hexcasting.api.casting.eval.env.StaffCastEnv;
import at.petrak.hexcasting.api.casting.eval.vm.CastingImage;
import at.petrak.hexcasting.api.casting.eval.vm.CastingVM;
import net.minecraft.class_1268;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_3222;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;
import org.ladysnake.cca.api.v3.component.Component;

public class CCStaffcastImage implements Component {
    public static final String TAG_VM = "harness";

    private final class_3222 owner;
    private class_2487 lazyLoadedTag = new class_2487();

    public CCStaffcastImage(class_3222 owner) {
        this.owner = owner;
    }

    /**
     * Turn the saved image into a VM in a player staffcasting environment
     */
    public CastingVM getVM(class_1268 hand) {
        var img = this.lazyLoadedTag.method_33133()
            ? new CastingImage()
            : CastingImage.getCODEC().parse(class_2509.field_11560, lazyLoadedTag).getOrThrow();
        var env = new StaffCastEnv(this.owner, hand);
        return new CastingVM(img, env);
    }

    public void setImage(@Nullable CastingImage image) {
        this.lazyLoadedTag =
            image == null
                ? new class_2487()
                : (class_2487) CastingImage.getCODEC().encode(image, class_2509.field_11560, new class_2487()).getOrThrow();
    }

    @Override
    public void readFromNbt(class_2487 tag, class_7225.class_7874 provider) {
        this.lazyLoadedTag = tag.method_10562(TAG_VM);
    }

    @Override
    public void writeToNbt(class_2487 tag, class_7225.class_7874 provider) {
        tag.method_10566(TAG_VM, this.lazyLoadedTag);
    }
}
