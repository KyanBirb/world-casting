package at.petrak.hexcasting.fabric.cc;

import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_2487;
import net.minecraft.class_7225;
import net.minecraft.class_9129;
import org.ladysnake.cca.api.v3.component.Component;
import org.ladysnake.cca.api.v3.component.sync.AutoSyncedComponent;

public class CCBrainswept implements Component, AutoSyncedComponent {
    public static final String TAG_BRAINSWEPT = "brainswept";

    private final class_1309 owner;

    public CCBrainswept(class_1309 owner) {
        this.owner = owner;
    }

    private boolean brainswept = false;

    public boolean isBrainswept() {
        return this.brainswept;
    }

    public void setBrainswept(boolean brainswept) {
        this.brainswept = brainswept;
        HexCardinalComponents.BRAINSWEPT.sync(this.owner);
    }

    @Override
    public void applySyncPacket(class_9129 buf) {
        AutoSyncedComponent.super.applySyncPacket(buf);
        if (owner instanceof class_1308 mob && brainswept)
            mob.method_35056();
    }

    @Override
    public void readFromNbt(class_2487 tag, class_7225.class_7874 registryLookup) {
        this.brainswept = tag.method_10577(TAG_BRAINSWEPT);
    }

    @Override
    public void writeToNbt(class_2487 tag, class_7225.class_7874 registryLookup) {
        tag.method_10556(TAG_BRAINSWEPT, this.brainswept);
    }
}
