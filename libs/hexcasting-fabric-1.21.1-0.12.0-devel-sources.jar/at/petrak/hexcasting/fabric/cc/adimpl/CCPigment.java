package at.petrak.hexcasting.fabric.cc.adimpl;

import at.petrak.hexcasting.api.addldata.ADPigment;
import at.petrak.hexcasting.api.item.PigmentItem;
import at.petrak.hexcasting.api.pigment.ColorProvider;
import org.ladysnake.cca.api.v3.component.TransientComponent;

import java.util.UUID;
import net.minecraft.class_1799;

/**
 * The pigment itself
 */
public abstract class CCPigment implements ADPigment, TransientComponent {

    public final class_1799 stack;

    public CCPigment(class_1799 stack) {
        this.stack = stack;
    }

    public static class ItemBased extends CCPigment {
        private final PigmentItem item;

        public ItemBased(class_1799 owner) {
            super(owner);
            var item = owner.method_7909();
            if (!(item instanceof PigmentItem col)) {
                throw new IllegalStateException("item is not a pigment: " + owner);
            }
            this.item = col;
        }

        @Override
        public ColorProvider provideColor(UUID owner) {
            return item.provideColor(this.stack, owner);
        }
    }
}
