package at.petrak.hexcasting.fabric.cc.adimpl;

import at.petrak.hexcasting.api.addldata.ADVariantItem;
import at.petrak.hexcasting.api.item.VariantItem;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_7225;
import org.ladysnake.cca.api.v3.component.Component;

public abstract class CCVariantItem implements ADVariantItem, Component {
    final class_1799 stack;
    public CCVariantItem(class_1799 stack) {
        this.stack = stack;
    }

    public static class ItemBased extends CCVariantItem {
        private final VariantItem variantItem;

        public ItemBased(class_1799 owner) {
            super(owner);
            var item = owner.method_7909();
            if (!(item instanceof VariantItem variantItem)) {
                throw new IllegalStateException("item is not a colorizer: " + owner);
            }
            this.variantItem = variantItem;
        }

        @Override
        public int numVariants() {
            return variantItem.numVariants();
        }

        @Override
        public int getVariant() {
            return variantItem.getVariant(this.stack);
        }

        @Override
        public void setVariant(int variant) {
            variantItem.setVariant(this.stack, variant);
        }

        @Override
        public void readFromNbt(class_2487 tag, class_7225.class_7874 registryLookup) {

        }

        @Override
        public void writeToNbt(class_2487 tag, class_7225.class_7874 registryLookup) {

        }
    }
}
