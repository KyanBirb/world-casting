package at.petrak.hexcasting.fabric.interop.accessories;

import at.petrak.hexcasting.common.lib.HexItems;
import io.wispforest.accessories.api.client.AccessoryRenderer;
import io.wispforest.accessories.api.slot.SlotReference;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_583;
import net.minecraft.class_591;
import net.minecraft.class_7833;
import net.minecraft.class_811;

/**
 * @author WireSegal
 * Created at 9:50 AM on 7/25/22.
 */
public class LensAccessoryRenderer implements AccessoryRenderer {
    @Override
    @SuppressWarnings("unchecked")
    public <M extends class_1309> void render(class_1799 stack, SlotReference slotReference, class_4587 matrices, class_583<M> model, class_4597 multiBufferSource, int light, float v, float v1, float v2, float v3, float v4, float v5) {
        if (stack.method_31574(HexItems.SCRYING_LENS) &&
                model instanceof class_591 playerModel && slotReference.entity() instanceof class_1657) {

            // from https://github.com/Creators-of-Create/Create/blob/ee33823ed0b5084af10ed131a1626ce71db4c07e/src/main/java/com/simibubi/create/compat/curios/GogglesCurioRenderer.java

            // Translate and rotate with our head
            matrices.method_22903();

            // Translate and scale to our head
            matrices.method_22904(0, 0, 0.3);
            matrices.method_22907(class_7833.field_40718.rotationDegrees(180.0f));
            matrices.method_22905(0.625f, 0.625f, 0.625f);

            // Render
            var instance = class_310.method_1551();
            instance.method_1480().method_23178(stack, class_811.field_4316,
                    light, class_4608.field_21444, matrices, multiBufferSource, instance.field_1687, 0);
            matrices.method_22909();
        }
    }
}
