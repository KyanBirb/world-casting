package at.petrak.hexcasting.fabric.loot;

import at.petrak.hexcasting.common.lib.HexItems;
import at.petrak.hexcasting.common.loot.AddHexToAncientCypherFunc;
import at.petrak.hexcasting.common.loot.AddPerWorldPatternToScrollFunc;
import at.petrak.hexcasting.fabric.FabricHexInitializer;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_219;
import net.minecraft.class_2246;
import net.minecraft.class_2960;
import net.minecraft.class_44;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_5341;
import net.minecraft.class_55;
import net.minecraft.class_5662;
import net.minecraft.class_77;
import net.minecraft.class_83;

import static at.petrak.hexcasting.api.HexAPI.modLoc;
import static at.petrak.hexcasting.common.loot.HexLootHandler.TABLE_INJECT_AMETHYST_CLUSTER;

public class FabricHexLootModJankery {
    public static final class_2960 FUNC_AMETHYST_SHARD_REDUCER = modLoc("amethyst_shard_reducer");
    public static final class_2960 RANDOM_SCROLL_TABLE = modLoc("random_scroll");
    public static final class_2960 RANDOM_CYPHER_TABLE = modLoc("random_cypher");

    public static void lootLoad(class_5321<class_52> id, Consumer<class_55.class_56> addPool) {
        if (id.equals(class_2246.field_27161.method_26162())) {
            addPool.accept(makeAmethystInjectPool());
        } else if (id.equals(RANDOM_SCROLL_TABLE)) {
            // -1 weight = guaranteed spawn
            addPool.accept(makeScrollAddPool(-1));
        } else if (id.equals(RANDOM_CYPHER_TABLE)) {
            // 1 chance = guaranteed spawn
            addPool.accept(makeCypherAddPool(1));
        }

        int countRange = FabricHexInitializer.CONFIG.server.scrollRangeForLootTable(id.method_29177());
        if (countRange != -1) {
            addPool.accept(makeScrollAddPool(countRange));
        }

        if (FabricHexInitializer.CONFIG.server.shouldInjectLore(id.method_29177())) {
            addPool.accept(makeLoreAddPool(FabricHexInitializer.CONFIG.server.loreChance()));
        }

        if (FabricHexInitializer.CONFIG.server.shouldInjectCyphers(id.method_29177())) {
            addPool.accept(makeCypherAddPool(FabricHexInitializer.CONFIG.server.cypherChance()));
        }
    }

    @NotNull
    private static class_55.class_56 makeAmethystInjectPool() {
        return class_55.method_347()
            .method_351(class_83.method_428(TABLE_INJECT_AMETHYST_CLUSTER));
    }

    private static class_55.class_56 makeScrollAddPool(int range) {
        return class_55.method_347()
            .method_352(range < 0 ? class_44.method_32448(1) : class_5662.method_32462(-range, range))
            .method_351(class_77.method_411(HexItems.SCROLL_LARGE))
            .method_353(() -> new AddPerWorldPatternToScrollFunc(List.of(new class_5341[0])));
    }

    private static class_55.class_56 makeLoreAddPool(double chance) {
        return class_55.method_347()
            .method_356(class_219.method_932((float) chance))
            .method_352(class_44.method_32448(1))
            .method_351(class_77.method_411(HexItems.LORE_FRAGMENT));
    }

    private static class_55.class_56 makeCypherAddPool(double chance) {
        return class_55.method_347()
            .method_356(class_219.method_932((float) chance))
            .method_352(class_44.method_32448(1))
            .method_351(class_77.method_411(HexItems.ANCIENT_CYPHER))
            .method_353(() -> new AddHexToAncientCypherFunc(List.of(new class_5341[0])));
    }
}
