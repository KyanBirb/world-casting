package at.petrak.hexcasting.xplat;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.api.client.ClientCastingStack;
import java.util.ServiceLoader;
import java.util.stream.Collectors;
import net.minecraft.class_1044;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1800;
import net.minecraft.class_1921;
import net.minecraft.class_2248;
import net.minecraft.class_238;
import net.minecraft.class_2960;
import net.minecraft.class_5617;
import net.minecraft.class_8710;

public interface IClientXplatAbstractions {
    void sendPacketToServer(class_8710 packet);

    void setRenderLayer(class_2248 block, class_1921 type);

    void initPlatformSpecific();

    <T extends class_1297> void registerEntityRenderer(class_1299<? extends T> type, class_5617<T> renderer);

    void registerItemProperty(class_1792 item, class_2960 id, class_1800 func);

    ClientCastingStack getClientCastingStack(class_1657 player);

    // On Forge, these are already exposed; on Farbc we do a mixin
    void setFilterSave(class_1044 texture, boolean filter, boolean mipmap);

    void restoreLastFilter(class_1044 texture);

    boolean fabricAdditionalQuenchFrustumCheck(class_238 aabb);

    IClientXplatAbstractions INSTANCE = find();
    /**
     * Returns a block model variant string, either INVENTORY_VARIANT or STANDALONE_VARIANT depending on the mod loader.
     * Used for ModelResourceLocations.
     * On Fabric, the STANDALONE_VARIANT does not exist, so we grab the INVENTORY_VARIANT instead.
     */
    String getModelLocVariant();

    private static IClientXplatAbstractions find() {
        var providers = ServiceLoader.load(IClientXplatAbstractions.class).stream().toList();
        if (providers.size() != 1) {
            var names = providers.stream().map(p -> p.type().getName()).collect(Collectors.joining(",", "[", "]"));
            throw new IllegalStateException(
                "There should be exactly one IClientXplatAbstractions implementation on the classpath. Found: " + names);
        } else {
            var provider = providers.get(0);
            HexAPI.LOGGER.debug("Instantiating client xplat impl: " + provider.type().getName());
            return provider.get();
        }
    }
}
