package at.petrak.hexcasting.xplat;

import net.minecraft.class_1792;
import net.minecraft.class_6862;

// https://fabricmc.net/wiki/tutorial:tags#existing_common_tags
public interface IXplatTags {
    class_6862<class_1792> amethystDust();

    class_6862<class_1792> gems();
}
