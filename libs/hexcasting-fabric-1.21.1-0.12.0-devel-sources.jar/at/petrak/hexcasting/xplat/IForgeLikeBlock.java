package at.petrak.hexcasting.xplat;

import net.minecraft.class_1309;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_4538;

/**
 * An interface that mimics some methods of IForgeBlock.
 * Fabric implementation will use mixins to achieve the same effects.
 */
public interface IForgeLikeBlock {
    default boolean addLandingEffects(class_2680 state, class_3218 level, class_2338 pos, class_1309 entity, int numberOfParticles) {
        return false;
    }

    default boolean hasEnchantPowerBonus(class_2680 state, class_4538 level, class_2338 pos) {
        return false;
    }
}
