package at.petrak.hexcasting.common.items;

import at.petrak.hexcasting.annotations.SoftImplement;
import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.common.lib.HexAttributes;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import net.minecraft.class_1304;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1738;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2315;
import net.minecraft.class_2342;
import net.minecraft.class_2969;
import net.minecraft.class_6880;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class ItemLens extends class_1792 implements HexBaubleItem { // Wearable,

    // The 0.1 is *additive*

    public static final class_1322 GRID_ZOOM = new class_1322(
            HexAPI.modLoc("scrying_lens_zoom"), 0.33, class_1322.class_1323.field_6330);

    public static final class_1322 SCRY_SIGHT = new class_1322(
            HexAPI.modLoc("scrying_lens_sight"), 1.0, class_1322.class_1323.field_6328);

    public ItemLens(class_1793 pProperties) {
        super(pProperties);
        class_2315.method_10009(this, new class_2969() {
            protected @NotNull class_1799 method_10135(@NotNull class_2342 world, @NotNull class_1799 stack) {
                this.method_27955(class_1738.method_7684(world, stack));
                return stack;
            }
        });
    }

    @Override
    public Multimap<class_6880<class_1320>, class_1322> getHexBaubleAttrs(class_1799 stack) {
        HashMultimap<class_6880<class_1320>, class_1322> out = HashMultimap.create();
        out.put(HexAttributes.GRID_ZOOM, GRID_ZOOM);
        out.put(HexAttributes.SCRY_SIGHT, SCRY_SIGHT);
        return out;
    }

    // In fabric impled with extension property?
    @Nullable
    @SoftImplement("forge")
    public class_1304 getEquipmentSlot(class_1799 stack) {
        return class_1304.field_6169;
    }

//    @Nullable
//    @Override
//    public SoundEvent getEquipSound() {
//        return SoundEvents.AMETHYST_BLOCK_CHIME;
//    }

}
