package at.petrak.hexcasting.common.items.armor;

import at.petrak.hexcasting.api.HexAPI;
import net.minecraft.class_1738;
import net.minecraft.class_6880;

/**
 * To get the armor model in;
 * On forge: cursed self-mixin
 * On fabric: hook in ClientInit
 */
public class ItemRobes extends class_1738 {
    public final class_1738.class_8051 type;

    public ItemRobes(class_1738.class_8051 type, class_1793 properties) {
        super(class_6880.method_40223(HexAPI.instance().robesMaterial()), type, properties);
        this.field_41933 = type;
    }
}
