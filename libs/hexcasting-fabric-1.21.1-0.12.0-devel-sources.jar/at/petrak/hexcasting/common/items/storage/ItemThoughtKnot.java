package at.petrak.hexcasting.common.items.storage;

import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.item.IotaHolderItem;
import at.petrak.hexcasting.common.lib.HexDataComponents;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

// Would love to be able to just write to a piece of string but the api requires it to be the same item
public class ItemThoughtKnot extends class_1792 implements IotaHolderItem {
    public static final class_2960 WRITTEN_PRED = modLoc("written");

    public ItemThoughtKnot(class_1793 properties) {
        super(properties);
    }

    @Override
    public boolean writeable(class_1799 stack) {
        return !stack.method_57826(HexDataComponents.IOTA_HOLDER_IOTA);
    }

    @Override
    public boolean canWrite(class_1799 stack, @Nullable Iota iota) {
        return iota != null && writeable(stack);
    }

    @Override
    public void writeDatum(class_1799 stack, @Nullable Iota iota) {
        if (iota != null) {
            stack.method_57379(HexDataComponents.IOTA_HOLDER_IOTA, iota);
        }
    }

    @Override
    public void method_7851(class_1799 pStack, class_9635 context,
        List<class_2561> pTooltipComponents, class_1836 pIsAdvanced) {
        IotaHolderItem.appendHoverText(this, pStack, pTooltipComponents, pIsAdvanced);
    }
}
