package at.petrak.hexcasting.common.items;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.common.lib.HexAttributes;
import at.petrak.hexcasting.common.lib.HexSounds;
import at.petrak.hexcasting.common.msgs.MsgClearSpiralPatternsS2C;
import at.petrak.hexcasting.common.msgs.MsgOpenSpellGuiS2C;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3468;

public class ItemStaff extends class_1792 {
    // 0 = normal. 1 = old. 2 = cherry preview
    public static final class_2960 FUNNY_LEVEL_PREDICATE = class_2960.method_60655(HexAPI.MOD_ID, "funny_level");

    public ItemStaff(class_1793 pProperties) {
        super(pProperties);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 player, class_1268 hand) {
        if (player.method_45325(HexAttributes.FEEBLE_MIND) > 0){
            return class_1271.method_22431(player.method_5998(hand));
        }
        if (player.method_5715()) {
            if (world.method_8608()) {
                player.method_5783(HexSounds.STAFF_RESET, 1f, 1f);
            } else if (player instanceof class_3222 serverPlayer) {
                IXplatAbstractions.INSTANCE.clearCastingData(serverPlayer);
                var packet = new MsgClearSpiralPatternsS2C(player.method_5667());
                IXplatAbstractions.INSTANCE.sendPacketToPlayer(serverPlayer, packet);
                IXplatAbstractions.INSTANCE.sendPacketTracking(serverPlayer, packet);
            }
        }

        if (!world.method_8608() && player instanceof class_3222 serverPlayer) {
            var vm = IXplatAbstractions.INSTANCE.getStaffcastVM(serverPlayer, hand);
            var patterns = IXplatAbstractions.INSTANCE.getPatternsSavedInUi(serverPlayer);

            class_2487 ravenmind = vm.getImage().ravenmind().orElse(new class_2487());


            IXplatAbstractions.INSTANCE.sendPacketToPlayer(serverPlayer,
                new MsgOpenSpellGuiS2C(hand, patterns, vm.getImage().getStack(), ravenmind,
                    0)); // TODO: Fix!
        }

        player.method_7259(class_3468.field_15372.method_14956(this));
//        player.gameEvent(GameEvent.ITEM_INTERACT_START);

        return class_1271.method_22427(player.method_5998(hand));
    }

}
