package at.petrak.hexcasting.common.items.pigment;

import at.petrak.hexcasting.api.item.PigmentItem;
import at.petrak.hexcasting.api.pigment.ColorProvider;
import java.util.UUID;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_243;

public class ItemDyePigment extends class_1792 implements PigmentItem {
    private final class_1767 dyeColor;

    public ItemDyePigment(class_1767 dyeColor, class_1793 pProperties) {
        super(pProperties);
        this.dyeColor = dyeColor;
    }

    public class_1767 getDyeColor() {
        return dyeColor;
    }

    @Override
    public ColorProvider provideColor(class_1799 stack, UUID owner) {
        return colorProvider;
    }

    protected MyColorProvider colorProvider = new MyColorProvider();

    protected class MyColorProvider extends ColorProvider {
        @Override
        protected int getRawColor(float time, class_243 position) {
            return dyeColor.method_16357();
        }
    }
}
