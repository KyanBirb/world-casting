package at.petrak.hexcasting.common.items.pigment;

import at.petrak.hexcasting.api.item.PigmentItem;
import at.petrak.hexcasting.api.pigment.ColorProvider;
import java.util.UUID;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_243;

public class ItemAmethystPigment extends class_1792 implements PigmentItem {
    public ItemAmethystPigment(class_1793 pProperties) {
        super(pProperties);
    }

    @Override
    public ColorProvider provideColor(class_1799 stack, UUID owner) {
        return colorProvider;
    }

    protected MyColorProvider colorProvider = new MyColorProvider();

    protected class MyColorProvider extends ColorProvider {
        @Override
        protected int getRawColor(float time, class_243 position) {
            return 0xff_ab65eb;
        }
    }
}
