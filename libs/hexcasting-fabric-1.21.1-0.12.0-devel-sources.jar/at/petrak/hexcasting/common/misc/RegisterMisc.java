package at.petrak.hexcasting.common.misc;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.mixin.accessor.AccessorAbstractArrow;
import at.petrak.hexcasting.mixin.accessor.AccessorVillager;
import net.minecraft.class_1299;
import net.minecraft.class_1665;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_4140;

public class RegisterMisc {
    public static void register() {
        HexAPI.instance().registerSpecialVelocityGetter(class_1299.field_6097, player -> {
            if (player instanceof class_3222 splayer) {
                return PlayerPositionRecorder.getMotion(splayer);
            } else {
                // bruh
                throw new IllegalStateException("Call this only on the server side, silly");
            }
        });

        HexAPI.instance().registerSpecialVelocityGetter(class_1299.field_6122, RegisterMisc::arrowVelocitizer);
        HexAPI.instance().registerSpecialVelocityGetter(class_1299.field_6135, RegisterMisc::arrowVelocitizer);
        // this is an arrow apparently
        HexAPI.instance().registerSpecialVelocityGetter(class_1299.field_6127, RegisterMisc::arrowVelocitizer);

        HexAPI.instance().registerCustomBrainsweepingBehavior(class_1299.field_6077, villager -> {
            ((AccessorVillager) villager).hex$releaseAllPois();
            HexAPI.instance().defaultBrainsweepingBehavior().accept(villager);
        });
        HexAPI.instance().registerCustomBrainsweepingBehavior(class_1299.field_38384, allay -> {
            allay.method_18868().method_18875(class_4140.field_38394);
            HexAPI.instance().defaultBrainsweepingBehavior().accept(allay);
        });
    }

    private static class_243 arrowVelocitizer(class_1665 arrow) {
        if (((AccessorAbstractArrow) arrow).hex$isInGround()) {
            return class_243.field_1353;
        } else {
            return arrow.method_18798();
        }
    }
}
