package at.petrak.hexcasting.common.recipe;

import at.petrak.hexcasting.api.HexAPI;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_2960;
import net.minecraft.class_3956;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class HexRecipeStuffRegistry {
    public static void registerSerializers(BiConsumer<class_1865<?>, class_2960> r) {
        for (var e : SERIALIZERS.entrySet()) {
            r.accept(e.getValue(), e.getKey());
        }
    }

    public static void registerTypes(BiConsumer<class_3956<?>, class_2960> r) {
        for (var e : TYPES.entrySet()) {
            r.accept(e.getValue(), e.getKey());
        }
    }

    private static final Map<class_2960, class_1865<?>> SERIALIZERS = new LinkedHashMap<>();
    private static final Map<class_2960, class_3956<?>> TYPES = new LinkedHashMap<>();

    public static final class_1865<?> BRAINSWEEP = registerSerializer("brainsweep",
        new BrainsweepRecipe.Serializer());
    public static final class_1865<SealThingsRecipe> SEAL_FOCUS = registerSerializer(
        "seal_focus", SealThingsRecipe.FOCUS_SERIALIZER);
    public static final class_1865<SealThingsRecipe> SEAL_SPELLBOOK = registerSerializer(
        "seal_spellbook", SealThingsRecipe.SPELLBOOK_SERIALIZER);

    public static class_3956<BrainsweepRecipe> BRAINSWEEP_TYPE = registerType("brainsweep");

    private static <T extends class_1860<?>> class_1865<T> registerSerializer(String name, class_1865<T> rs) {
        var old = SERIALIZERS.put(modLoc(name), rs);
        if (old != null) {
            throw new IllegalArgumentException("Typo? Duplicate id " + name);
        }
        return rs;
    }

    private static <T extends class_1860<?>> class_3956<T> registerType(String name) {
        var type = new class_3956<T>() {
            @Override
            public String toString() {
                return HexAPI.MOD_ID + ":" + name;
            }
        };
        // never will be a collision because it's a new object
        TYPES.put(modLoc(name), type);
        return type;
    }
}
