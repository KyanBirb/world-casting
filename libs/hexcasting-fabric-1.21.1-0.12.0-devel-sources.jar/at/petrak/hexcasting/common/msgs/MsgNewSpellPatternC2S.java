package at.petrak.hexcasting.common.msgs;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.api.casting.eval.ResolvedPattern;
import at.petrak.hexcasting.api.casting.eval.env.StaffCastEnv;
import at.petrak.hexcasting.api.casting.math.HexPattern;
import net.minecraft.class_1268;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.server.MinecraftServer;
import java.util.List;

/**
 * Sent client->server when the player finishes drawing a pattern.
 * Server will send back a {@link MsgNewSpellPatternS2C} packet
 */
public record MsgNewSpellPatternC2S(class_1268 handUsed, HexPattern pattern,
                                    List<ResolvedPattern> resolvedPatterns) implements class_8710 {
    public static final class_8710.class_9154<MsgNewSpellPatternC2S> TYPE = new class_8710.class_9154<>(HexAPI.modLoc("pat_cs"));

    public static final class_9139<class_9129, MsgNewSpellPatternC2S> STREAM_CODEC = class_9139.method_56436(
            class_9135.field_48547.method_56432(
                    isMain -> isMain ? class_1268.field_5808 : class_1268.field_5810,
                    hand -> hand == class_1268.field_5808
            ), MsgNewSpellPatternC2S::handUsed,
            HexPattern.STREAM_CODEC, MsgNewSpellPatternC2S::pattern,
            ResolvedPattern.STREAM_CODEC.method_56433(class_9135.method_56363()), MsgNewSpellPatternC2S::resolvedPatterns,
            MsgNewSpellPatternC2S::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    public void handle(MinecraftServer server, class_3222 sender) {
        server.execute(() -> StaffCastEnv.handleNewPatternOnServer(sender, this));
    }
}
