package at.petrak.hexcasting.common.msgs;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.xplat.IClientXplatAbstractions;
import java.util.UUID;
import net.minecraft.class_310;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record MsgClearSpiralPatternsS2C(UUID playerUUID) implements class_8710 {
    public static final class_8710.class_9154<MsgClearSpiralPatternsS2C> TYPE = new class_8710.class_9154<>(HexAPI.modLoc("clr_spi_pats_sc"));

    public static final class_9139<class_9129, MsgClearSpiralPatternsS2C> STREAM_CODEC = class_4844.field_48453.method_56432(
            MsgClearSpiralPatternsS2C::new,
            MsgClearSpiralPatternsS2C::playerUUID
    ).method_56439(b -> b);

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    public void handle() {
        Handler.handle(this);
    }

    public static final class Handler {

        public static void handle(MsgClearSpiralPatternsS2C self) {
            class_310.method_1551().execute(() -> {
                var mc = class_310.method_1551();
                assert mc.field_1687 != null;
                var player = mc.field_1687.method_18470(self.playerUUID);
                var stack = IClientXplatAbstractions.INSTANCE.getClientCastingStack(player);
                stack.slowClear();
            });
        }
    }
}
