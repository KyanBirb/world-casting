package at.petrak.hexcasting.common.msgs;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.api.casting.ParticleSpray;
import at.petrak.hexcasting.api.pigment.FrozenPigment;
import at.petrak.hexcasting.client.ClientTickCounter;
import at.petrak.hexcasting.common.particles.ConjureParticleOptions;
import java.util.Random;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/**
 * Sent server->client to spray particles everywhere.
 */
public record MsgCastParticleS2C(ParticleSpray spray, FrozenPigment colorizer) implements class_8710 {
    public static final class_8710.class_9154<MsgCastParticleS2C> TYPE = new class_8710.class_9154<>(HexAPI.modLoc("cprtcl"));

    public static final class_9139<class_9129, MsgCastParticleS2C> STREAM_CODEC = class_9139.method_56435(
            ParticleSpray.getSTREAM_CODEC(), MsgCastParticleS2C::spray,
            FrozenPigment.STREAM_CODEC, MsgCastParticleS2C::colorizer,
            MsgCastParticleS2C::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    private static final Random RANDOM = new Random();

    // https://math.stackexchange.com/questions/44689/how-to-find-a-random-axis-or-unit-vector-in-3d
    private static class_243 randomInCircle(double maxTh) {
        var th = RANDOM.nextDouble(0.0, maxTh + 0.001);
        var z = RANDOM.nextDouble(-1.0, 1.0);
        return new class_243(Math.sqrt(1.0 - z * z) * Math.cos(th), Math.sqrt(1.0 - z * z) * Math.sin(th), z);
    }

    public void handle() {
        Handler.handle(this);
    }

    public static final class Handler {

        public static void handle(MsgCastParticleS2C msg) {
            class_310.method_1551().execute(() -> {
                var colProvider = msg.colorizer().getColorProvider();
                for (int i = 0; i < msg.spray().getCount(); i++) {
                    // For the colors, pick any random time to get a mix of colors

                    var offset = randomInCircle(class_3532.field_29846).method_1029()
                            .method_1021(RANDOM.nextFloat() * msg.spray().getFuzziness() / 2);
                    var pos = msg.spray().getPos().method_1019(offset);

                    var phi = Math.acos(1.0 - RANDOM.nextDouble() * (1.0 - Math.cos(msg.spray().getSpread())));
                    var theta = Math.PI * 2.0 * RANDOM.nextDouble();
                    var v = msg.spray().getVel().method_1029();
                    // pick any old vector to get a vector normal to v with
                    class_243 k;
                    if (v.field_1352 == 0.0 && v.field_1351 == 0.0) {
                        // oops, pick a *different* normal
                        k = new class_243(1.0, 0.0, 0.0);
                    } else {
                        k = v.method_1036(new class_243(0.0, 0.0, 1.0));
                    }
                    var velUnlen = v.method_1021(Math.cos(phi))
                            .method_1019(k.method_1021(Math.sin(phi) * Math.cos(theta)))
                            .method_1019(v.method_1036(k).method_1021(Math.sin(phi) * Math.sin(theta)));
                    var vel = velUnlen.method_1021(msg.spray().getVel().method_1033() / 20);

                    var color = colProvider.getColor(ClientTickCounter.getTotal(), velUnlen);

                    class_310.method_1551().field_1687.method_8406(
                            new ConjureParticleOptions(color),
                            pos.field_1352, pos.field_1351, pos.field_1350,
                            vel.field_1352, vel.field_1351, vel.field_1350
                    );
                }
            });
        }
    }
}
