package at.petrak.hexcasting.common.msgs;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.xplat.IClientXplatAbstractions;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_310;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record MsgNewSpiralPatternsS2C(UUID playerUUID, List<HexPattern> patterns, int lifetime) implements class_8710 {
    public static final class_8710.class_9154<MsgNewSpiralPatternsS2C> TYPE = new class_8710.class_9154<>(HexAPI.modLoc("spi_pats_sc"));

    public static final class_9139<class_9129, MsgNewSpiralPatternsS2C> STREAM_CODEC = class_9139.method_56436(
            class_4844.field_48453, MsgNewSpiralPatternsS2C::playerUUID,
            HexPattern.STREAM_CODEC.method_56433(class_9135.method_56363()), MsgNewSpiralPatternsS2C::patterns,
            class_9135.field_48550, MsgNewSpiralPatternsS2C::lifetime,
            MsgNewSpiralPatternsS2C::new
    );

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    public void handle() {
        Handler.handle(this);
    }

    public static final class Handler {

        public static void handle(MsgNewSpiralPatternsS2C self) {
            class_310.method_1551().execute(() -> {
                var mc = class_310.method_1551();
                assert mc.field_1687 != null;
                var player = mc.field_1687.method_18470(self.playerUUID);
                var stack = IClientXplatAbstractions.INSTANCE.getClientCastingStack(player);

                for (var pattern : self.patterns)
                    stack.addPattern(pattern, self.lifetime);
            });
        }
    }
}
