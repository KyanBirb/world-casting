package at.petrak.hexcasting.common.msgs;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.paucal.api.PaucalCodecs;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2766;
import net.minecraft.class_310;
import net.minecraft.class_3419;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record MsgBeepS2C(class_243 target, int note, class_2766 instrument) implements class_8710 {
    public static final class_8710.class_9154<MsgBeepS2C> TYPE = new class_8710.class_9154<>(HexAPI.modLoc("beep"));

    public static final class_9139<class_9129, MsgBeepS2C> STREAM_CODEC = class_9139.method_56436(
            PaucalCodecs.VEC3, MsgBeepS2C::target,
            class_9135.field_48550, MsgBeepS2C::note,
            class_9135.method_56375(
                    (num) -> class_2766.values()[num],
                    class_2766::ordinal
            ), MsgBeepS2C::instrument,
            MsgBeepS2C::new
    );

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    public void handle() {
        Handler.handle(this);
    }

    public static final class Handler {

        public static void handle(MsgBeepS2C msg) {
            class_310.method_1551().execute(() -> {
                var minecraft = class_310.method_1551();
                var world = minecraft.field_1687;
                if (world != null) {
                    float pitch = (float) Math.pow(2, (msg.note() - 12) / 12.0);
                    world.method_8486(msg.target().field_1352, msg.target().field_1351, msg.target().field_1350,
                            msg.instrument().method_11886().comp_349(), class_3419.field_15248, 3, pitch, false);
                    world.method_8406(class_2398.field_11224, msg.target().field_1352, msg.target().field_1351 + 0.2, msg.target().field_1350,
                            msg.note() / 24.0, 0, 0);
                }
            });
        }
    }


}
