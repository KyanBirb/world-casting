package at.petrak.hexcasting.common.command;

import at.petrak.hexcasting.server.ScrungledPatternsSave;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;

public class RecalcPatternsCommand {
    public static void add(LiteralArgumentBuilder<class_2168> cmd) {
        cmd.then(class_2170.method_9247("recalcPatterns")
            .requires(dp -> dp.method_9259(class_2170.field_31840))
            .executes(ctx -> {
                var world = ctx.getSource().method_9211().method_30002();
                var ds = world.method_17983();
                ds.method_123(ScrungledPatternsSave.TAG_SAVED_DATA,
                    ScrungledPatternsSave.createFromScratch(world.method_8412()));

                ctx.getSource().method_9226(() ->
                    class_2561.method_43471("command.hexcasting.recalc"), true);
                return 1;
            }));
    }
}
