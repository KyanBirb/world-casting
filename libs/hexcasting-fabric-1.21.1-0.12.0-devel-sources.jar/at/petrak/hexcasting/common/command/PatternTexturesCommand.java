package at.petrak.hexcasting.common.command;

import at.petrak.hexcasting.client.render.PatternTextureManager;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;

public class PatternTexturesCommand
{
    public static void add(LiteralArgumentBuilder<class_2168> cmd) {
        // TODO: do we want these in release ??
        cmd.then(class_2170.method_9247("textureToggle")
                .requires(dp -> dp.method_9259(class_2170.field_31840))
                .executes(ctx -> {
                    PatternTextureManager.useTextures = !PatternTextureManager.useTextures;
                    String log = (PatternTextureManager.useTextures ? "Enabled" : "Disabled") + " pattern texture rendering. This is meant for debugging.";
                    ctx.getSource().method_9226(() -> class_2561.method_43470(log), true);
                    return 1;
                }));
        cmd.then(class_2170.method_9247("textureRepaint")
                .requires(dp -> dp.method_9259(class_2170.field_31840))
                .executes(ctx -> {
                    PatternTextureManager.repaint();
                    ctx.getSource().method_9226(() -> class_2561.method_43470("Repainting pattern textures. This is meant for debugging."), true);
                    return 1;
                }));
    }
}