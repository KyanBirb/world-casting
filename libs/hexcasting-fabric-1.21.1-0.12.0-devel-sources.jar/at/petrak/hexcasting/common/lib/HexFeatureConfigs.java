package at.petrak.hexcasting.common.lib;

import at.petrak.hexcasting.api.HexAPI;
import com.mojang.serialization.JsonOps;
import java.util.OptionalInt;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_4643;
import net.minecraft.class_4651;
import net.minecraft.class_4657;
import net.minecraft.class_5204;
import net.minecraft.class_5207;
import net.minecraft.class_5212;
import net.minecraft.class_6005;
import net.minecraft.class_6016;

public class HexFeatureConfigs {
    public static void dumpConfigs() {
        // Used to generate the tree data json files
        // Call this after the game is properly bootstrapped and copy the output logs to data/hexcasting/worldgen/configured_feature/${name}.json
        // This should be done in DataGen, but I was unable to make that function. - dashkal16
        HexAPI.LOGGER.info(class_4643.field_24921.encodeStart(JsonOps.INSTANCE, AMETHYST_EDIFIED_TREE_CONFIG));
        HexAPI.LOGGER.info(class_4643.field_24921.encodeStart(JsonOps.INSTANCE, AVENTURINE_EDIFIED_TREE_CONFIG));
        HexAPI.LOGGER.info(class_4643.field_24921.encodeStart(JsonOps.INSTANCE, CITRINE_EDIFIED_TREE_CONFIG));
    }

    public static final class_4643 AMETHYST_EDIFIED_TREE_CONFIG = akashicTree(HexBlocks.AMETHYST_EDIFIED_LEAVES, HexBlocks.EDIFIED_LOG_AMETHYST);
    public static final class_4643 AVENTURINE_EDIFIED_TREE_CONFIG = akashicTree(HexBlocks.AVENTURINE_EDIFIED_LEAVES, HexBlocks.EDIFIED_LOG_AVENTURINE);
    public static final class_4643 CITRINE_EDIFIED_TREE_CONFIG = akashicTree(HexBlocks.CITRINE_EDIFIED_LEAVES, HexBlocks.EDIFIED_LOG_CITRINE);

    private static class_4643 akashicTree(class_2248 leaves, class_2248 altLog) {
        return new class_4643.class_4644(
                new class_4657(
                        class_6005.<class_2680>method_34971()
                                .method_34975(HexBlocks.EDIFIED_LOG.method_9564(), 8)
                                .method_34975(altLog.method_9564(), 1)
                                .method_34974()),
                // baseHeight, heightRandA, heightRandB
                new class_5212(5, 5, 3),
                class_4651.method_38432(leaves),
                // radius, offset, height
                new class_5207(class_6016.method_34998(1), class_6016.method_34998(5), 5),
                // limit, lower size, upper size, minclippedheight
                new class_5204(0, 0, 0, OptionalInt.of(6))
        ).method_23445();
    }
}
