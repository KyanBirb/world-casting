package at.petrak.hexcasting.common.lib;

import at.petrak.hexcasting.api.casting.eval.env.PlayerBasedCastEnv;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import at.petrak.hexcasting.xplat.IXplatRegister;
import net.minecraft.class_1320;
import net.minecraft.class_1329;
import net.minecraft.class_6880;
import net.minecraft.class_7924;

import static at.petrak.hexcasting.api.HexAPI.MOD_ID;

public class HexAttributes {
    private static final IXplatRegister<class_1320> REGISTER = IXplatAbstractions.INSTANCE
            .createRegistar(class_7924.field_41251);

    public static void register() {
        REGISTER.registerAll();
    }

    public static final class_6880<class_1320> GRID_ZOOM = REGISTER.registerHolder("grid_zoom", () -> new class_1329(
            MOD_ID + ".attributes.grid_zoom", 1.0, 0.5, 4.0).method_26829(true));

    /**
     * Whether you have the lens overlay when looking at something. 0 = no, > 0 = yes.
     */
    public static final class_6880<class_1320> SCRY_SIGHT = REGISTER.registerHolder("scry_sight", () -> new class_1329(
            MOD_ID + ".attributes.scry_sight", 0.0, 0.0, 1.0).method_26829(true));

    //whether the player is allowed to use staffcasting and scrying lenses
    public static final class_6880<class_1320> FEEBLE_MIND = REGISTER.registerHolder("feeble_mind", () -> new class_1329(
            MOD_ID + ".attributes.feeble_mind", 0.0, 0.0, 1.0).method_26829(true));

    //a multiplier to adjust media consumption across the board
    public static final class_6880<class_1320> MEDIA_CONSUMPTION_MODIFIER = REGISTER.registerHolder("media_consumption", () -> new class_1329(
            MOD_ID + ".attributes.media_consumption", 1.0, 0.0, Double.MAX_VALUE).method_26829(true));

    public static final class_6880<class_1320> AMBIT_RADIUS = REGISTER.registerHolder("ambit_radius", () -> new class_1329(
            MOD_ID + ".attributes.ambit_radius", PlayerBasedCastEnv.DEFAULT_AMBIT_RADIUS, 0.0, Double.MAX_VALUE).method_26829(true));

    public static final class_6880<class_1320> SENTINEL_RADIUS = REGISTER.registerHolder("sentinel_radius", () -> new class_1329(
            MOD_ID + ".attributes.sentinel_radius", PlayerBasedCastEnv.DEFAULT_SENTINEL_RADIUS, 0.0, Double.MAX_VALUE).method_26829(true));
}
