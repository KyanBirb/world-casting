package at.petrak.hexcasting.common.lib;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

import net.minecraft.class_5321;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import net.minecraft.class_8108;
import net.minecraft.class_8110;

public class HexDamageTypes {
    public static final class_5321<class_8110> OVERCAST = class_5321.method_29179(class_7924.field_42534, modLoc("overcast"));

    public static void bootstrap(class_7891<class_8110> ctx) {
        ctx.method_46838(OVERCAST, new class_8110(
            "hexcasting.overcast",
            class_8108.field_42286,
            0f
        ));
    }
}
