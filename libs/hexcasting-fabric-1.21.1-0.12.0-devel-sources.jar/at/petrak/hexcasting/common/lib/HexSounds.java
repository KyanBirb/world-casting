package at.petrak.hexcasting.common.lib;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import net.minecraft.class_2960;
import net.minecraft.class_3414;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class HexSounds {
    public static void registerSounds(BiConsumer<class_3414, class_2960> r) {
        for (var e : SOUNDS.entrySet()) {
            r.accept(e.getValue(), e.getKey());
        }
    }

    private static final Map<class_2960, class_3414> SOUNDS = new LinkedHashMap<>();

    public static final class_3414 START_PATTERN = sound("casting.pattern.start");
    public static final class_3414 ADD_TO_PATTERN = sound("casting.pattern.add_segment");

    public static final class_3414 CASTING_AMBIANCE = sound("casting.ambiance");

    public static final class_3414 CAST_NORMAL = sound("casting.cast.normal");
    public static final class_3414 CAST_SPELL = sound("casting.cast.spell");
    public static final class_3414 CAST_HERMES = sound("casting.cast.hermes");
    public static final class_3414 CAST_THOTH = sound("casting.cast.thoth");
    public static final class_3414 CAST_FAILURE = sound("casting.cast.fail");

    public static final class_3414 ABACUS = sound("abacus");
    public static final class_3414 ABACUS_SHAKE = sound("abacus.shake");

    public static final class_3414 STAFF_RESET = sound("staff.reset");

    public static final class_3414 SPELL_CIRCLE_FIND_BLOCK = sound("spellcircle.find_block");
    public static final class_3414 SPELL_CIRCLE_FAIL = sound("spellcircle.fail");

    public static final class_3414 SCROLL_DUST = sound("scroll.dust");
    public static final class_3414 SCROLL_SCRIBBLE = sound("scroll.scribble");

    public static final class_3414 IMPETUS_LOOK_TICK = sound("impetus.fletcher.tick");
    public static final class_3414 IMPETUS_REDSTONE_DING = sound("impetus.redstone.register");
    public static final class_3414 IMPETUS_REDSTONE_CLEAR = sound("impetus.redstone.clear");

    public static final class_3414 READ_LORE_FRAGMENT = sound("lore_fragment.read");

    public static final class_3414 FLIGHT_AMBIENCE = sound("flight.ambience");
    public static final class_3414 FLIGHT_FINISH = sound("flight.finish");

    private static class_3414 sound(String name) {
        var id = modLoc(name);
        var sound = class_3414.method_47908(id);
        var old = SOUNDS.put(id, sound);
        if (old != null) {
            throw new IllegalArgumentException("Typo? Duplicate id " + name);
        }
        return sound;
    }
}
