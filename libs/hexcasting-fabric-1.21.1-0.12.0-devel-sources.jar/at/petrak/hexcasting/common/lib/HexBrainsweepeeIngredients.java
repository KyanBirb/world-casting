package at.petrak.hexcasting.common.lib;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.common.recipe.ingredient.brainsweep.*;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.BiConsumer;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3852;
import net.minecraft.class_3854;
import net.minecraft.class_6862;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public class HexBrainsweepeeIngredients {
    public static final Codec<BrainsweepeeIngredient> TYPED_CODEC = Codec.lazyInitialized(() -> IXplatAbstractions.INSTANCE
            .getBrainsweepeeIngredientRegistry()
            .method_39673()
            .dispatch("type", BrainsweepeeIngredient::getType, BrainsweepeeIngredientType::codec));
    public static final class_9139<class_9129, BrainsweepeeIngredient> TYPED_STREAM_CODEC = class_9135
            .method_56365(HexRegistries.BRAINSWEEPEE_INGREDIENT)
            .method_56440(BrainsweepeeIngredient::getType, BrainsweepeeIngredientType::streamCodec);

    public static final BrainsweepeeIngredientType<EntityTypeIngredient> ENTITY_TYPE = new EntityTypeIngredient.Type();
    public static final BrainsweepeeIngredientType<EntityTagIngredient> TAG = new EntityTagIngredient.Type();
    public static final BrainsweepeeIngredientType<VillagerIngredient> VILLAGER = new VillagerIngredient.Type();

    public static final BrainsweepeeIngredientType<? extends BrainsweepeeIngredient> NONE_TYPE = new BrainsweepeeIngredientType<>() {
        @Override
        public MapCodec<BrainsweepeeIngredient> codec() {
            return MapCodec.unit(NONE);
        }

        @Override
        public class_9139<class_9129, BrainsweepeeIngredient> streamCodec() {
            return class_9139.method_56431(NONE);
        }
    };

    public static final BrainsweepeeIngredient NONE = new BrainsweepeeIngredient() {

        @Override
        public BrainsweepeeIngredientType<?> getType() {
            return NONE_TYPE;
        }

        @Override
        public boolean test(class_1297 entity, class_3218 level) {
            return false;
        }

        @Override
        public class_2561 getName() {
            return class_2561.method_43470("none");
        }

        @Override
        public List<class_2561> getTooltip(boolean advanced) {
            return List.of();
        }

        @Override
        public String getSomeKindOfReasonableIDForEmi() {
            return "none";
        }

        @Override
        public @Nullable class_1297 exampleEntity(class_1937 level) {
            return null;
        }
    };

    public static void register(BiConsumer<BrainsweepeeIngredientType<?>, class_2960> r) {
        r.accept(NONE_TYPE, HexAPI.modLoc("none"));
        r.accept(ENTITY_TYPE, HexAPI.modLoc("entity_type"));
        r.accept(TAG, HexAPI.modLoc("entity_tag"));
        r.accept(VILLAGER, HexAPI.modLoc("villager"));
    }

    public static BrainsweepeeIngredient of(class_1299<?> entityType) {
        return new EntityTypeIngredient(entityType);
    }

    public static BrainsweepeeIngredient of(class_6862<class_1299<?>> tagKey) {
        return new EntityTagIngredient(tagKey);
    }

    public static BrainsweepeeIngredient of(
        @Nullable class_3852 profession,
        @Nullable class_3854 biome,
        int minLevel
    ) {
        return new VillagerIngredient(profession, biome, minLevel);
    }
}
