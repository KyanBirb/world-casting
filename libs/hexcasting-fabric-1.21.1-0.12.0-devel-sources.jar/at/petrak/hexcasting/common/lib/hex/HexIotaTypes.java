package at.petrak.hexcasting.common.lib.hex;

import at.petrak.hexcasting.api.casting.iota.*;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import javax.annotation.ParametersAreNonnullByDefault;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.BiConsumer;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

/**
 * Stores the registry for iota types, some utility methods, and all the types Hexcasting itself defines.
 */
@ParametersAreNonnullByDefault
public class HexIotaTypes {
    public static final class_2378<IotaType<?>> REGISTRY = IXplatAbstractions.INSTANCE.getIotaTypeRegistry();
    public static final int MAX_SERIALIZATION_DEPTH = 256;
    public static final int MAX_SERIALIZATION_TOTAL = 1024;

    private static final Map<class_2960, IotaType<?>> TYPES = new LinkedHashMap<>();

    public static final IotaType<NullIota> NULL = type("null", NullIota.TYPE);
    public static final IotaType<DoubleIota> DOUBLE = type("double", DoubleIota.TYPE);
    public static final IotaType<BooleanIota> BOOLEAN = type("boolean", BooleanIota.TYPE);
    public static final IotaType<EntityIota> ENTITY = type("entity", EntityIota.TYPE);
    public static final IotaType<ListIota> LIST = type("list", ListIota.TYPE);
    public static final IotaType<PatternIota> PATTERN = type("pattern", PatternIota.TYPE);
    public static final IotaType<GarbageIota> GARBAGE = type("garbage", GarbageIota.TYPE);
    public static final IotaType<Vec3Iota> VEC3 = type("vec3", Vec3Iota.TYPE);
    public static final IotaType<ContinuationIota> CONTINUATION = type("continuation", ContinuationIota.TYPE);

    public static void registerTypes(BiConsumer<IotaType<?>, class_2960> r) {
        for (var e : TYPES.entrySet()) {
            r.accept(e.getValue(), e.getKey());
        }
    }


    private static <U extends Iota, T extends IotaType<U>> T type(String name, T type) {
        var old = TYPES.put(modLoc(name), type);
        if (old != null) {
            throw new IllegalArgumentException("Typo? Duplicate id " + name);
        }
        return type;
    }
}
