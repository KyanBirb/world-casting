package at.petrak.hexcasting.common.blocks.circles.impetuses;

import at.petrak.hexcasting.api.block.circle.BlockAbstractImpetus;
import at.petrak.hexcasting.api.casting.circles.BlockEntityAbstractImpetus;
import at.petrak.hexcasting.api.casting.iota.EntityIota;
import at.petrak.hexcasting.common.lib.HexBlockEntities;
import at.petrak.hexcasting.common.lib.HexSounds;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_3218;
import net.minecraft.class_3419;
import net.minecraft.class_3965;
import net.minecraft.class_5819;
import net.minecraft.class_9062;
import org.jetbrains.annotations.Nullable;

public class BlockRedstoneImpetus extends BlockAbstractImpetus {
    public static final class_2746 POWERED = class_2741.field_12484;

    public BlockRedstoneImpetus(class_2251 p_49795_) {
        super(p_49795_);
    }

    @Override
    public class_2591<? extends BlockEntityAbstractImpetus> getBlockEntityType() {
        return HexBlockEntities.IMPETUS_REDSTONE_TILE;
    }

    @Override
    public class_1269 use(class_2680 pState, class_1937 pLevel, class_2338 pPos, class_1657 pPlayer, class_1268 pHand, class_3965 pHit) {
        return null;
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pPos, class_2680 pState) {
        return new BlockEntityRedstoneImpetus(pPos, pState);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(POWERED);
    }

    @Override
    protected class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult) {
        if (level instanceof class_3218 sLevel
                && level.method_8321(pos) instanceof BlockEntityRedstoneImpetus tile) {
            var usedStack = player.method_5998(hand);
            if (usedStack.method_7960() && player.method_21751()) {
                tile.clearPlayer();
                tile.sync();
                level.method_8396(null, pos, HexSounds.IMPETUS_REDSTONE_CLEAR, class_3419.field_15245, 1f, 1f);
                return class_9062.method_55644(level.field_9236);
            } else {
                var datumContainer = IXplatAbstractions.INSTANCE.findDataHolder(usedStack);
                if (datumContainer != null) {
                    var stored = datumContainer.readIota();
                    if (stored instanceof EntityIota eieio) {
                        var entity = eieio.getEntity(sLevel);
                        if (entity instanceof class_1657 iotaPlayer) {
                            // phew, we got something
                            tile.setPlayer(iotaPlayer.method_7334(), entity.method_5667());
                            tile.sync();

                            level.method_8396(null, pos, HexSounds.IMPETUS_REDSTONE_DING,
                                    class_3419.field_15245, 1f, 1f);
                            return class_9062.method_55644(level.field_9236);
                        }
                    }
                }
            }
        }

        return stack.method_7960() && hand == class_1268.field_5808
                ? class_9062.field_47732
                : class_9062.field_47731;
    }

    @Override
    public void method_9588(class_2680 pState, class_3218 pLevel, class_2338 pPos, class_5819 pRandom) {
        super.method_9588(pState, pLevel, pPos, pRandom);
        if (pLevel.method_8321(pPos) instanceof BlockEntityRedstoneImpetus tile) {
            tile.updatePlayerProfile();
        }
    }

    @Override
    public void method_9612(class_2680 pState, class_1937 pLevel, class_2338 pPos, class_2248 pBlock, class_2338 pFromPos,
        boolean pIsMoving) {
        super.method_9612(pState, pLevel, pPos, pBlock, pFromPos, pIsMoving);

        if (pLevel instanceof class_3218 slevel) {
            boolean prevPowered = pState.method_11654(POWERED);
            boolean isPowered = pLevel.method_49803(pPos);

            if (prevPowered != isPowered) {
                pLevel.method_8501(pPos, pState.method_11657(POWERED, isPowered));

                if (isPowered && pLevel.method_8321(pPos) instanceof BlockEntityRedstoneImpetus tile) {
                    var player = tile.getStoredPlayer();
                    tile.startExecution(player);
                }
            }
        }
    }
}
