package at.petrak.hexcasting.common.blocks.decoration;

import net.minecraft.class_2465;

public class BlockAxis extends class_2465 {
    public BlockAxis(class_2251 p_55926_) {
        super(p_55926_);
    }
}
