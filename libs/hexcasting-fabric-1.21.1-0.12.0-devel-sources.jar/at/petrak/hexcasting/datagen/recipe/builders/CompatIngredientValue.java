package at.petrak.hexcasting.datagen.recipe.builders;

import com.google.gson.JsonObject;
import org.jetbrains.annotations.NotNull;

import java.util.Collection;
import java.util.Collections;
import java.util.stream.Stream;
import net.minecraft.class_1799;
import net.minecraft.class_1856;

public class CompatIngredientValue implements class_1856.class_1859 {
    public final String item;

    public CompatIngredientValue(String name) {
        this.item = name;
    }

    public @NotNull Collection<class_1799> method_8108() {
        return Collections.emptyList();
    }

    public @NotNull JsonObject serialize() {
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("item", item);
        return jsonObject;
    }

    public static class_1856 of(String itemName) {
        return new class_1856(Stream.of(new CompatIngredientValue(itemName)));
    }
}

