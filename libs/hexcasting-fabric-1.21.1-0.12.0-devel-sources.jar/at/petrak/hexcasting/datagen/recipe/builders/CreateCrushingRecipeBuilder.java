package at.petrak.hexcasting.datagen.recipe.builders;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_175;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_2960;
import net.minecraft.class_5797;
import net.minecraft.class_8790;

// Largely adapted from the following classes:
// https://github.com/Creators-of-Create/Create/blob/82be76d8934af03b4e52cad6a9f74a4175ba7b05/src/main/java/com/simibubi/create/content/contraptions/processing/ProcessingOutput.java
// https://github.com/Creators-of-Create/Create/blob/82be76d8934af03b4e52cad6a9f74a4175ba7b05/src/main/java/com/simibubi/create/foundation/data/recipe/ProcessingRecipeGen.java
// https://github.com/Creators-of-Create/Create/blob/82be76d8934af03b4e52cad6a9f74a4175ba7b05/src/main/java/com/simibubi/create/content/contraptions/processing/ProcessingRecipeBuilder.java
// https://github.com/Creators-of-Create/Create/blob/82be76d8934af03b4e52cad6a9f74a4175ba7b05/src/main/java/com/simibubi/create/content/contraptions/processing/ProcessingRecipeSerializer.java
public class CreateCrushingRecipeBuilder implements class_5797 {
    private String group = "";
    private class_1856 input;
    private final List<ProcessingOutput> results = new ArrayList<>();
    private int processingTime = 100;

    @Override
    public class_5797 method_33530(String name, class_175<?> criterion) {
        return this;
    }

    @Override
    public @NotNull CreateCrushingRecipeBuilder method_33529(@Nullable String name) {
        group = name;
        return this;
    }

    public CreateCrushingRecipeBuilder duration(int duration) {
        this.processingTime = duration;
        return this;
    }

    public CreateCrushingRecipeBuilder withInput(class_1935 item) {
        return withInput(class_1856.method_8091(item));
    }

    public CreateCrushingRecipeBuilder withInput(class_1799 stack) {
        return withInput(class_1856.method_8101(stack));
    }

    public CreateCrushingRecipeBuilder withInput(class_1856 ingredient) {
        this.input = ingredient;
        return this;
    }

    public CreateCrushingRecipeBuilder withOutput(class_1935 output) {
        return withOutput(1f, output, 1);
    }

    public CreateCrushingRecipeBuilder withOutput(float chance, class_1935 output) {
        return withOutput(chance, output, 1);
    }

    public CreateCrushingRecipeBuilder withOutput(class_1935 output, int count) {
        return withOutput(1f, output, count);
    }

    public CreateCrushingRecipeBuilder withOutput(float chance, class_1935 output, int count) {
        return withOutput(new class_1799(output, count), chance);
    }

    public CreateCrushingRecipeBuilder withOutput(class_1799 output, float chance) {
        //this.results.add(new ItemProcessingOutput(output, chance));
        return this;
    }

    public CreateCrushingRecipeBuilder withOutput(String name) {
        return withOutput(1f, name, 1);
    }

    public CreateCrushingRecipeBuilder withOutput(String name, int count) {
        return withOutput(1f, name, count);
    }

    public CreateCrushingRecipeBuilder withOutput(float chance, String name) {
        return withOutput(chance, name, 1);
    }

    public CreateCrushingRecipeBuilder withOutput(float chance, String name, int count) {
        //this.results.add(new CompatProcessingOutput(name, count, chance));
        return this;
    }

    @Override
    public @NotNull class_1792 method_36441() {
        return class_1802.field_8162; // Irrelevant, we implement serialization ourselves
    }

    @Override
    public void method_17972(class_8790 recipeOutput, class_2960 id) {

    }
}
