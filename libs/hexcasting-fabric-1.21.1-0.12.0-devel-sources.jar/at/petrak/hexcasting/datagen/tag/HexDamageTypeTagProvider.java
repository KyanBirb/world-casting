package at.petrak.hexcasting.datagen.tag;

import at.petrak.hexcasting.common.lib.HexDamageTypes;
import org.jetbrains.annotations.NotNull;

import java.util.concurrent.CompletableFuture;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_7784;
import net.minecraft.class_8103;
import net.minecraft.class_8110;
import net.minecraft.class_8142;

public class HexDamageTypeTagProvider extends class_8142 {
    public HexDamageTypeTagProvider(class_7784 output, CompletableFuture<class_7225.class_7874> provider) {
        super(output, provider);
    }

    @Override
    protected void method_10514(@NotNull class_7225.class_7874 provider) {
        add(HexDamageTypes.OVERCAST,
            class_8103.field_42241,
            class_8103.field_42243,
            class_8103.field_43116
        );
    }

    @SafeVarargs
    private void add(class_5321<class_8110> damageType, class_6862<class_8110>... tags) {
        for (var tag : tags) {
            this.method_10512(tag).method_46835(damageType);
        }
    }
}
