package at.petrak.hexcasting.datagen;

import at.petrak.hexcasting.datagen.recipe.builders.FarmersDelightToolIngredient;
import java.util.EnumMap;
import net.minecraft.class_1767;
import net.minecraft.class_1856;

public interface IXplatIngredients {
    class_1856 glowstoneDust();

    class_1856 leather();

    class_1856 ironNugget();

    class_1856 goldNugget();

    class_1856 copperIngot();

    class_1856 ironIngot();

    class_1856 goldIngot();

    EnumMap<class_1767, class_1856> dyes();

    class_1856 stick();

    class_1856 whenModIngredient(class_1856 defaultIngredient, String modid, class_1856 modIngredient);

    FarmersDelightToolIngredient axeStrip();

    FarmersDelightToolIngredient axeDig();
}
