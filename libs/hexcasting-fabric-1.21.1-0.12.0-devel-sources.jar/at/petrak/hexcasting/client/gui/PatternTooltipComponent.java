package at.petrak.hexcasting.client.gui;

import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.client.render.PatternColors;
import at.petrak.hexcasting.client.render.PatternRenderer;
import at.petrak.hexcasting.client.render.WorldlyPatternRenderHelpers;
import at.petrak.hexcasting.common.misc.PatternTooltip;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5632;
import net.minecraft.class_5684;
import org.jetbrains.annotations.Nullable;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

// https://github.com/VazkiiMods/Botania/blob/95bd2d3fbc857b7c102687554e1d1b112f8af436/Xplat/src/main/java/vazkii/botania/client/gui/ManaBarTooltipComponent.java
// yoink

/**
 * @see PatternTooltip the associated data for this
 */
public class PatternTooltipComponent implements class_5684 {
    public static final class_2960 PRISTINE_BG = modLoc("textures/gui/scroll.png");
    public static final class_2960 ANCIENT_BG = modLoc("textures/gui/scroll_ancient.png");
    public static final class_2960 SLATE_BG = modLoc("textures/gui/slate.png");

    private static final float RENDER_SIZE = 128f;
    private static final int TEXTURE_SIZE = 48;

    private final HexPattern pattern;
    private final class_2960 background;

    public PatternTooltipComponent(PatternTooltip tt) {
        this.pattern = tt.pattern();
        this.background = tt.background();
    }

    @Nullable
    public static class_5684 tryConvert(class_5632 cmp) {
        if (cmp instanceof PatternTooltip ptt) {
            return new PatternTooltipComponent(ptt);
        }
        return null;
    }

    @Override
    public void method_32666(class_327 font, int mouseX, int mouseY, class_332 graphics) {
        var ps = graphics.method_51448();

        // far as i can tell "mouseX" and "mouseY" are actually the positions of the corner of the tooltip
        ps.method_22903();
        ps.method_46416(mouseX, mouseY, 500);
        RenderSystem.enableBlend();
        renderBG(graphics, this.background);

        // renderText happens *before* renderImage for some asinine reason
        ps.method_46416(0, 0, 100);
        ps.method_22905(RENDER_SIZE, RENDER_SIZE, 1);

        PatternRenderer.renderPattern(pattern, ps, WorldlyPatternRenderHelpers.READABLE_SCROLL_SETTINGS,
                (PatternRenderer.shouldDoStrokeGradient() ? PatternColors.DEFAULT_GRADIENT_COLOR : PatternColors.DEFAULT_PATTERN_COLOR)
                        .withDots(true, true),
                0, 512);

        ps.method_22909();
    }

    private static void renderBG(class_332 graphics, class_2960 background) {
        graphics.method_25293(
            background, // texture
            0, 0, // x, y
            (int) RENDER_SIZE, (int) RENDER_SIZE, // renderWidth, renderHeight
            0f, 0f, // u, v (textureCoords)
            TEXTURE_SIZE, TEXTURE_SIZE, // regionWidth, regionHeight (texture sample dimensions)
            TEXTURE_SIZE, TEXTURE_SIZE); // textureWidth, textureHeight (total dimensions of texture)
    }

    @Override
    public int method_32664(class_327 pFont) {
        return (int) RENDER_SIZE;
    }

    @Override
    public int method_32661() {
        return (int) RENDER_SIZE;
    }
}
