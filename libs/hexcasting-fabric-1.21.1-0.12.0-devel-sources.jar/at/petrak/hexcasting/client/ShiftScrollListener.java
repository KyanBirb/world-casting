package at.petrak.hexcasting.client;

import at.petrak.hexcasting.api.mod.HexConfig;
import at.petrak.hexcasting.common.lib.HexItems;
import at.petrak.hexcasting.common.msgs.MsgShiftScrollC2S;
import at.petrak.hexcasting.xplat.IClientXplatAbstractions;
import net.minecraft.class_1792;
import net.minecraft.class_310;
import net.minecraft.class_746;

public class ShiftScrollListener {
    private static double mainHandDelta = 0;
    private static double offHandDelta = 0;

    public static boolean onScrollInGameplay(double delta) {
        if (class_310.method_1551().field_1755 != null) {
            return false;
        }

        return onScroll(delta, true);
    }

    public static boolean onScroll(double delta, boolean needsSneaking) {
        class_746 player = class_310.method_1551().field_1724;
        // not .isCrouching! that fails for players who are not on the ground
        // yes, this does work if you remap your sneak key
        if (player != null && (player.method_5715() || !needsSneaking)) {
            // Spectators shouldn't interact with items!
            if (player.method_7325()) {
                return false;
            }

            if (IsScrollableItem(player.method_6047().method_7909())) {
                mainHandDelta += delta;
                return true;
            } else if (IsScrollableItem(player.method_6079().method_7909())) {
                offHandDelta += delta;
                return true;
            }
        }

        return false;
    }

    public static void clientTickEnd() {
        if (mainHandDelta != 0 || offHandDelta != 0) {
            IClientXplatAbstractions.INSTANCE.sendPacketToServer(
                new MsgShiftScrollC2S(mainHandDelta, offHandDelta, class_310.method_1551().field_1690.field_1867.method_1434(),
                    HexConfig.client().invertSpellbookScrollDirection(),
                    HexConfig.client().invertAbacusScrollDirection()));
            mainHandDelta = 0;
            offHandDelta = 0;
        }
    }

    private static boolean IsScrollableItem(class_1792 item) {
        return item == HexItems.SPELLBOOK || item == HexItems.ABACUS;
    }
}
