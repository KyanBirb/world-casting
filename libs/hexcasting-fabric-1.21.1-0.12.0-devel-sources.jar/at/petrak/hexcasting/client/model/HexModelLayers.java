package at.petrak.hexcasting.client.model;

import java.util.function.BiConsumer;
import java.util.function.Supplier;
import net.minecraft.class_5601;
import net.minecraft.class_5607;
import net.minecraft.class_563;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

// https://github.com/VazkiiMods/Botania/blob/1.19.x/Xplat/src/main/java/vazkii/botania/client/model/BotaniaModelLayers.java
public class HexModelLayers {
    public static final class_5601 ALTIORA = make("altiora");

    public static final class_5601 ROBES = make("robes");

    private static class_5601 make(String name) {
        return make(name, "main");
    }

    private static class_5601 make(String name, String layer) {
        // Don't add to vanilla's ModelLayers. It seems to only be used for error checking
        // And would be annoying to do under Forge's parallel mod loading
        return new class_5601(modLoc(name), layer);
    }

    // moving this stuff into the same file:
    // https://github.com/VazkiiMods/Botania/blob/1.19.x/Xplat/src/main/java/vazkii/botania/client/model/BotaniaLayerDefinitions.java
    public static void init(BiConsumer<class_5601, Supplier<class_5607>> consumer) {
        consumer.accept(ALTIORA, class_563::method_31994);
        consumer.accept(ROBES, HexRobesModels::variant1);
    }
}
