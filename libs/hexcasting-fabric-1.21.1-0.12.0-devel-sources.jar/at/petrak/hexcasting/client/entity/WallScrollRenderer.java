package at.petrak.hexcasting.client.entity;

import at.petrak.hexcasting.client.render.WorldlyPatternRenderHelpers;
import at.petrak.hexcasting.common.entities.EntityWallScroll;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5617;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_7833;
import net.minecraft.class_897;
import org.joml.Matrix4f;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class WallScrollRenderer extends class_897<EntityWallScroll> {
    private static final class_2960 PRISTINE_BG_LARGE = modLoc("textures/entity/scroll_large.png");
    private static final class_2960 PRISTINE_BG_MEDIUM = modLoc("textures/entity/scroll_medium.png");
    private static final class_2960 PRISTINE_BG_SMOL = modLoc("textures/block/scroll_paper.png");
    private static final class_2960 ANCIENT_BG_LARGE = modLoc("textures/entity/scroll_ancient_large.png");
    private static final class_2960 ANCIENT_BG_MEDIUM = modLoc("textures/entity/scroll_ancient_medium.png");
    private static final class_2960 ANCIENT_BG_SMOL = modLoc("textures/block/ancient_scroll_paper.png");

    public WallScrollRenderer(class_5617.class_5618 p_174008_) {
        super(p_174008_);
    }

    // I do as the PaintingRenderer guides
    @Override
    public void render(EntityWallScroll wallScroll, float yaw, float partialTicks, class_4587 ps,
        class_4597 bufSource, int packedLight) {

        RenderSystem.setShader(class_757::method_34542);

        ps.method_22903();

        ps.method_22907(class_7833.field_40716.rotationDegrees(180f - yaw));
        ps.method_22907(class_7833.field_40718.rotationDegrees(180f));

        int light = class_761.method_23794(wallScroll.method_37908(), wallScroll.method_59940());

        {
            ps.method_22903();
            // X is right, Y is down, Z is *in*
            // Our origin will be the lower-left corner of the scroll touching the wall
            // (so it has "negative" thickness)
            ps.method_46416(-wallScroll.blockSize / 2f, -wallScroll.blockSize / 2f, 1f / 32f);

            float dx = wallScroll.blockSize, dy = wallScroll.blockSize, dz = -1f / 16f;
            float margin = 1f / 48f;
            var last = ps.method_23760();
            var mat = last.method_23761();

            class_1921 layer = class_1921.method_23576(this.getTextureLocation(wallScroll));

            var verts = bufSource.getBuffer(layer);
            // Remember: CCW
            // Front face
            vertex(mat, last, light, verts, 0, 0, dz, 0, 0, 0, 0, -1);
            vertex(mat, last, light, verts, 0, dy, dz, 0, 1, 0, 0, -1);
            vertex(mat, last, light, verts, dx, dy, dz, 1, 1, 0, 0, -1);
            vertex(mat, last, light, verts, dx, 0, dz, 1, 0, 0, 0, -1);
            // Back face
            vertex(mat, last, light, verts, 0, 0, 0, 0, 0, 0, 0, 1);
            vertex(mat, last, light, verts, dx, 0, 0, 1, 0, 0, 0, 1);
            vertex(mat, last, light, verts, dx, dy, 0, 1, 1, 0, 0, 1);
            vertex(mat, last, light, verts, 0, dy, 0, 0, 1, 0, 0, 1);
            // Top face
            vertex(mat, last, light, verts, 0, 0, 0, 0, 0, 0, -1, 0);
            vertex(mat, last, light, verts, 0, 0, dz, 0, margin, 0, -1, 0);
            vertex(mat, last, light, verts, dx, 0, dz, 1, margin, 0, -1, 0);
            vertex(mat, last, light, verts, dx, 0, 0, 1, 0, 0, -1, 0);
            // Left face
            vertex(mat, last, light, verts, 0, 0, 0, 0, 0, -1, 0, 0);
            vertex(mat, last, light, verts, 0, dy, 0, 0, 1, -1, 0, 0);
            vertex(mat, last, light, verts, 0, dy, dz, margin, 1, -1, 0, 0);
            vertex(mat, last, light, verts, 0, 0, dz, margin, 0, -1, 0, 0);
            // Right face
            vertex(mat, last, light, verts, dx, 0, dz, 1 - margin, 0, 1, 0, 0);
            vertex(mat, last, light, verts, dx, dy, dz, 1 - margin, 1, 1, 0, 0);
            vertex(mat, last, light, verts, dx, dy, 0, 1, 1, 1, 0, 0);
            vertex(mat, last, light, verts, dx, 0, 0, 1, 0, 1, 0, 0);
            // Bottom face
            vertex(mat, last, light, verts, 0, dy, dz, 0, 1 - margin, 0, 1, 0);
            vertex(mat, last, light, verts, 0, dy, 0, 0, 1, 0, 1, 0);
            vertex(mat, last, light, verts, dx, dy, 0, 1, 1, 0, 1, 0);
            vertex(mat, last, light, verts, dx, dy, dz, 1, 1 - margin, 0, 1, 0);

            ps.method_22909();

            if(wallScroll.pattern != null)
                WorldlyPatternRenderHelpers.renderPatternForScroll(wallScroll.pattern, wallScroll, ps, bufSource, light, wallScroll.blockSize, wallScroll.getShowsStrokeOrder());
        }

        ps.method_22909();
        super.method_3936(wallScroll, yaw, partialTicks, ps, bufSource, packedLight);
    }

    @Override
    public class_2960 getTextureLocation(EntityWallScroll wallScroll) {
        if (wallScroll.isAncient) {
            if (wallScroll.blockSize <= 1) {
                return ANCIENT_BG_SMOL;
            } else if (wallScroll.blockSize == 2) {
                return ANCIENT_BG_MEDIUM;
            } else {
                return ANCIENT_BG_LARGE;
            }
        } else {
            if (wallScroll.blockSize <= 1) {
                return PRISTINE_BG_SMOL;
            } else if (wallScroll.blockSize == 2) {
                return PRISTINE_BG_MEDIUM;
            } else {
                return PRISTINE_BG_LARGE;
            }
        }
    }

    private static void vertex(Matrix4f mat, class_4587.class_4665 last, int light, class_4588 verts, float x, float y,
                               float z, float u,
                               float v, float nx, float ny, float nz) {
        verts.method_22918(mat, x, y, z)
                .method_39415(0xffffffff)
                .method_22913(u, v)
                .method_22922(class_4608.field_21444)
                .method_60803(light)
                .method_60831(last, nx, ny, nz);
    }
}
