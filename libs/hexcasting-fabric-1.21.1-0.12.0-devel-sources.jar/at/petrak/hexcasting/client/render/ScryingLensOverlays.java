package at.petrak.hexcasting.client.render;

import at.petrak.hexcasting.api.block.circle.BlockAbstractImpetus;
import at.petrak.hexcasting.api.casting.circles.BlockEntityAbstractImpetus;
import at.petrak.hexcasting.api.client.ScryingLensOverlayRegistry;
import at.petrak.hexcasting.common.blocks.akashic.BlockEntityAkashicBookshelf;
import at.petrak.hexcasting.common.lib.HexBlocks;
import com.mojang.datafixers.util.Pair;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2286;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2428;
import net.minecraft.class_2442;
import net.minecraft.class_2457;
import net.minecraft.class_2462;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2680;
import net.minecraft.class_2747;
import net.minecraft.class_2766;
import net.minecraft.class_2768;
import net.minecraft.class_3532;
import net.minecraft.class_3620;
import net.minecraft.class_5251;
import net.minecraft.world.level.block.*;
import java.util.function.UnaryOperator;

public class ScryingLensOverlays {
    public static void addScryingLensStuff() {
        ScryingLensOverlayRegistry.addPredicateDisplayer(
            (state, pos, observer, world, direction) -> state.method_26204() instanceof BlockAbstractImpetus,
            (lines, state, pos, observer, world, direction) -> {
                if (world.method_8321(pos) instanceof BlockEntityAbstractImpetus beai) {
                    beai.applyScryingLensOverlay(lines, state, pos, observer, world, direction);
                }
            });

        ScryingLensOverlayRegistry.addDisplayer(class_2246.field_10179,
            (lines, state, pos, observer, world, direction) -> {
                int note = state.method_11654(class_2428.field_11324);

                float rCol = Math.max(0.0F, class_3532.method_15374((note / 24F + 0.0F) * class_3532.field_29846) * 0.65F + 0.35F);
                float gCol = Math.max(0.0F, class_3532.method_15374((note / 24F + 0.33333334F) * class_3532.field_29846) * 0.65F + 0.35F);
                float bCol = Math.max(0.0F, class_3532.method_15374((note / 24F + 0.6666667F) * class_3532.field_29846) * 0.65F + 0.35F);

                int noteColor = 0xFF_000000 | class_3532.method_15353(rCol, gCol, bCol);

                var instrument = state.method_11654(class_2428.field_11325);

                lines.add(new Pair<>(
                    new class_1799(class_1802.field_8623),
                    class_2561.method_43470(String.valueOf(instrument.ordinal()))
                        .method_27694(color(instrumentColor(instrument)))));
                lines.add(new Pair<>(
                    new class_1799(class_1802.field_8643),
                    class_2561.method_43470(String.valueOf(note))
                        .method_27694(color(noteColor))));
            });

        ScryingLensOverlayRegistry.addDisplayer(HexBlocks.AKASHIC_BOOKSHELF,
            (lines, state, pos, observer, world, direction) -> {
                if (world.method_8321(pos) instanceof BlockEntityAkashicBookshelf tile) {
                    var iota = tile.getIota();
                    if (iota != null) {
                        var display = iota.display();
                        lines.add(new Pair<>(new class_1799(class_1802.field_8529), display));
                    }
                }
            });

        ScryingLensOverlayRegistry.addDisplayer(class_2246.field_10377,
            (lines, state, pos, observer, world, direction) -> {
                int comparatorValue = state.method_26176(world, pos);
                lines.add(new Pair<>(
                    new class_1799(class_1802.field_8725),
                    class_2561.method_43470(comparatorValue == -1 ? "" : String.valueOf(comparatorValue))
                        .method_27694(redstoneColor(comparatorValue))));

                boolean compare = state.method_11654(class_2286.field_10789) == class_2747.field_12576;

                lines.add(new Pair<>(
                    new class_1799(class_1802.field_8530),
                    class_2561.method_43470(compare ? ">=" : "-")
                        .method_27694(redstoneColor(compare ? 0 : 15))));
            });

        ScryingLensOverlayRegistry.addDisplayer(class_2246.field_10425,
            (lines, state, pos, observer, world, direction) -> {
                int power = getPoweredRailStrength(world, pos, state);
                lines.add(new Pair<>(
                    new class_1799(class_1802.field_8848),
                    class_2561.method_43470(String.valueOf(power))
                        .method_27694(redstoneColor(power, 9))));
            });

        ScryingLensOverlayRegistry.addDisplayer(class_2246.field_10450,
            (lines, state, pos, observer, world, direction) -> lines.add(new Pair<>(
                new class_1799(class_1802.field_8557),
                class_2561.method_43470(String.valueOf(state.method_11654(class_2462.field_11451)))
                    .method_27692(class_124.field_1054))));

        ScryingLensOverlayRegistry.addPredicateDisplayer(
            (state, pos, observer, world, direction) -> state.method_26219() && !state.method_27852(
                class_2246.field_10377),
            (lines, state, pos, observer, world, direction) -> {
                int signalStrength = 0;
                if (state.method_26204() instanceof class_2457) {
                    signalStrength = state.method_11654(class_2457.field_11432);
                } else {
                    for (class_2350 dir : class_2350.values()) {
                        signalStrength = Math.max(signalStrength, state.method_26195(world, pos, dir));
                    }
                }

                lines.add(0, new Pair<>(
                    new class_1799(class_1802.field_8725),
                    class_2561.method_43470(String.valueOf(signalStrength))
                        .method_27694(redstoneColor(signalStrength))));
            });
    }

    private static int getPoweredRailStrength(class_1937 level, class_2338 pos, class_2680 state) {
        if (level.method_49803(pos))
            return 9;
        int positiveValue = findPoweredRailSignal(level, pos, state, true, 0);
        int negativeValue = findPoweredRailSignal(level, pos, state, false, 0);
        return Math.max(positiveValue, negativeValue);
    }

    // Copypasta from PoweredRailBlock.class
    private static int findPoweredRailSignal(class_1937 level, class_2338 pos, class_2680 state, boolean travelPositive,
        int depth) {
        if (depth >= 8) {
            return 0;
        } else {
            int x = pos.method_10263();
            int y = pos.method_10264();
            int z = pos.method_10260();
            boolean descending = true;
            class_2768 shape = state.method_11654(class_2442.field_11365);
            switch (shape) {
                case field_12665:
                    if (travelPositive) {
                        ++z;
                    } else {
                        --z;
                    }
                    break;
                case field_12674:
                    if (travelPositive) {
                        --x;
                    } else {
                        ++x;
                    }
                    break;
                case field_12667:
                    if (travelPositive) {
                        --x;
                    } else {
                        ++x;
                        ++y;
                        descending = false;
                    }

                    shape = class_2768.field_12674;
                    break;
                case field_12666:
                    if (travelPositive) {
                        --x;
                        ++y;
                        descending = false;
                    } else {
                        ++x;
                    }

                    shape = class_2768.field_12674;
                    break;
                case field_12670:
                    if (travelPositive) {
                        ++z;
                    } else {
                        --z;
                        ++y;
                        descending = false;
                    }

                    shape = class_2768.field_12665;
                    break;
                case field_12668:
                    if (travelPositive) {
                        ++z;
                        ++y;
                        descending = false;
                    } else {
                        --z;
                    }

                    shape = class_2768.field_12665;
            }

            int power = getPowerFromRail(level, new class_2338(x, y, z), travelPositive, depth,
                shape);

            if (power > 0) {
                return power;
            } else if (descending) {
                return getPowerFromRail(level, new class_2338(x, y - 1, z), travelPositive, depth,
                    shape);
            } else {
                return 0;
            }
        }
    }


    private static UnaryOperator<class_2583> color(int color) {
        return (style) -> style.method_27703(class_5251.method_27717(color));
    }

    private static UnaryOperator<class_2583> redstoneColor(int power) {
        return redstoneColor(power, 15);
    }

    private static UnaryOperator<class_2583> redstoneColor(int power, int max) {
        return color(class_2457.method_10487(class_3532.method_15340((power * max) / 15, 0, 15)));
    }

    private static int instrumentColor(class_2766 instrument) {
        return switch (instrument) {
            case field_12653 -> class_3620.field_16023.field_16011;
            case field_12643, field_12655, field_18289 -> class_3620.field_15986.field_16011;
            case field_12645 -> class_3620.field_16025.field_16011;
            case field_12651 -> class_3620.field_15996.field_16011;
            case field_12650 -> class_3620.field_15976.field_16011;
            case field_12644 -> class_3620.field_15994.field_16011;
            case field_12654 -> class_3620.field_15979.field_16011;
            case field_12647 -> class_3620.field_16016.field_16011;
            case field_18284 -> class_3620.field_16005.field_16011;
            case field_18285 -> class_3620.field_15977.field_16011;
            case field_18286 -> class_3620.field_15987.field_16011;
            case field_18287 -> class_3620.field_16001.field_16011;
            case field_18288 -> class_3620.field_16010.field_16011;
            default -> -1;
        };
    }

    private static int getPowerFromRail(class_1937 level, class_2338 pos, boolean travelPositive, int depth, class_2768 shape) {
        class_2680 otherState = level.method_8320(pos);
        if (!otherState.method_27852(class_2246.field_10425)) {
            return 0;
        } else {
            class_2768 otherShape = otherState.method_11654(class_2442.field_11365);
            if (shape == class_2768.field_12674 && (otherShape == class_2768.field_12665 || otherShape == class_2768.field_12670 || otherShape == class_2768.field_12668)) {
                return 0;
            } else if (shape == class_2768.field_12665 && (otherShape == class_2768.field_12674 || otherShape == class_2768.field_12667 || otherShape == class_2768.field_12666)) {
                return 0;
            } else if (otherState.method_11654(class_2442.field_11364)) {
                return level.method_49803(pos) ? 8 - depth : findPoweredRailSignal(level, pos, otherState,
                    travelPositive, depth + 1);
            } else {
                return 0;
            }
        }
    }
}
