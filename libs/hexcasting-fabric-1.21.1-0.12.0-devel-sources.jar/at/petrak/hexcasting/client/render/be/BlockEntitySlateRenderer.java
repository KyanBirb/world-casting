package at.petrak.hexcasting.client.render.be;

import at.petrak.hexcasting.client.render.WorldlyPatternRenderHelpers;
import at.petrak.hexcasting.common.blocks.circles.BlockEntitySlate;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_827;

public class BlockEntitySlateRenderer implements class_827<BlockEntitySlate> {
    public BlockEntitySlateRenderer(class_5614.class_5615 ctx) {
        // NO-OP
    }

    @Override
    public void render(BlockEntitySlate tile, float pPartialTick, class_4587 ps,
        class_4597 buffer, int light, int overlay) {
        if (tile.pattern == null)
            return;

        var bs = tile.method_11010();

        WorldlyPatternRenderHelpers.renderPatternForSlate(tile, tile.pattern, ps, buffer, light, bs);
    }
}