package at.petrak.hexcasting.client.render;

import java.awt.geom.Line2D;
import java.util.*;
import java.util.concurrent.*;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_241;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3545;
import net.minecraft.class_5253;

public class PatternTextureManager {

    //TODO: remove if not needed anymore for comparison
    public static boolean useTextures = true;
    public static int repaintIndex = 0;

    private static final ConcurrentMap<String, Map<String, class_2960>> patternTexturesToAdd = new ConcurrentHashMap<>();
    private static final Set<String> inProgressPatterns = new HashSet<>();
    // basically newCachedThreadPool, but with a max pool size
    private static final ExecutorService executor = new ThreadPoolExecutor(0, 16, 60L, TimeUnit.SECONDS, new LinkedBlockingDeque<>());

    private static final HashMap<String, Map<String, class_2960>> patternTextures = new HashMap<>();

    public static Optional<Map<String, class_2960>> getTextures(HexPatternLike patternlike, PatternSettings patSets, double seed, int resPerUnit) {
        String patCacheKey = patSets.getCacheKey(patternlike, seed) + "_" + resPerUnit;

        // move textures from concurrent map to normal hashmap as needed
        if (patternTexturesToAdd.containsKey(patCacheKey)) {
            var patternTexture = patternTexturesToAdd.remove(patCacheKey);
            var oldPatternTexture = patternTextures.put(patCacheKey, patternTexture);
            inProgressPatterns.remove(patCacheKey);
            if (oldPatternTexture != null) // TODO: is this needed? when does this ever happen?
                for(class_2960 oldPatternTextureSingle : oldPatternTexture.values())
                    class_310.method_1551().method_1531().method_4619(oldPatternTextureSingle).close();

            return Optional.empty(); // try not giving it immediately to avoid flickering?
        }
        if (patternTextures.containsKey(patCacheKey))
            return Optional.of(patternTextures.get(patCacheKey));

        // render a higher-resolution texture in a background thread so it eventually becomes all nice nice and pretty
        if(!inProgressPatterns.contains(patCacheKey)){
            inProgressPatterns.add(patCacheKey);
            executor.submit(() -> {
                var slowTextures = createTextures(patternlike, patSets, seed, resPerUnit);

                // TextureManager#register doesn't look very thread-safe, so move back to the main thread after the slow part is done
                class_310.method_1551().execute(() -> {
                        registerTextures(patCacheKey, slowTextures);
                });
            });
        }
        return Optional.empty();
    }

    private static Map<String, class_1043> createTextures(HexPatternLike patternlike, PatternSettings patSets, double seed, int resPerUnit) {
        HexPatternPoints staticPoints = HexPatternPoints.getStaticPoints(patternlike, patSets, seed);

        List<class_241> zappyRenderSpace = staticPoints.scaleVecs(staticPoints.zappyPoints);

        Map<String, class_1043> patTexts = new HashMap<>();

        class_1011 innerLines = drawLines(zappyRenderSpace, staticPoints, (float)patSets.getInnerWidth((staticPoints.finalScale)), resPerUnit);
        patTexts.put("inner", new class_1043(innerLines));

        class_1011 outerLines = drawLines(zappyRenderSpace, staticPoints, (float)patSets.getOuterWidth((staticPoints.finalScale)), resPerUnit);
        patTexts.put("outer", new class_1043(outerLines));

        return patTexts;
    }

    private static Map<String, class_2960> registerTextures(String patTextureKeyBase, Map<String, class_1043> dynamicTextures) {
        Map<String, class_2960> resLocs = new HashMap<>();
        for(Map.Entry<String, class_1043> textureEntry : dynamicTextures.entrySet()){
            String name = "hex_pattern_texture_" + patTextureKeyBase + "_" + textureEntry.getKey() + "_" + repaintIndex + ".png";
            class_2960 resourceLocation = class_310.method_1551().method_1531().method_4617(name, textureEntry.getValue());
            resLocs.put(textureEntry.getKey(), resourceLocation);
        }
        patternTexturesToAdd.put(patTextureKeyBase, resLocs);
        return resLocs;
    }

    private static class_1011 drawLines(List<class_241> points, HexPatternPoints staticPoints, float unscaledLineWidth, int resPerUnit) {
        class_1011 nativeImage = new class_1011((int)(staticPoints.fullWidth*resPerUnit), (int)(staticPoints.fullHeight*resPerUnit), true);
        for (int i = 0; i < points.size() - 1; i++) {
            class_3545<Integer, Integer> pointFrom = getTextureCoordinates(points.get(i), staticPoints, resPerUnit);
            class_3545<Integer, Integer> pointTo = getTextureCoordinates(points.get(i+1), staticPoints, resPerUnit);
           drawLine(nativeImage, pointFrom.method_15442(), pointFrom.method_15441(), pointTo.method_15442(), pointTo.method_15441(), unscaledLineWidth * resPerUnit);
        }
        return nativeImage;
    }

    private static void drawLine(class_1011 image, int x0, int y0, int x1, int y1, float width) {
        var line = new Line2D.Float(x0, y0, x1, y1);
        var bounds = line.getBounds();
        double halfWidth = width / 2;
        for (int x = (int) (bounds.x - width - 1); x < (int) (bounds.x + bounds.width + width + 1); x++) {
            for (int y = (int) (bounds.y - width - 1); y < (int) (bounds.y + bounds.height + width + 1); y++) {
                double dist = line.ptSegDist(x, y);
                int alpha = (int) (class_3532.method_15350(halfWidth - dist + 0.5, 0, 1) * 255);
                if (alpha > 0) {
                    int oldAlpha = class_5253.class_5254.method_27762(image.method_4315(x, y));
                    int newAlpha = Math.max(oldAlpha, alpha);
                    image.method_4305(x, y, 0xFFFFFF | (newAlpha << 24));
                }
            }
        }
    }

    private static class_3545<Integer, Integer> getTextureCoordinates(class_241 point, HexPatternPoints staticPoints, int resPerUnit) {
        int x = (int) ( point.field_1343 * resPerUnit);
        int y = (int) ( point.field_1342 * resPerUnit);
        return new class_3545<>(x, y);
    }

    public static void repaint() {
        repaintIndex++;
        patternTexturesToAdd.clear();
        patternTextures.clear();
    }
}