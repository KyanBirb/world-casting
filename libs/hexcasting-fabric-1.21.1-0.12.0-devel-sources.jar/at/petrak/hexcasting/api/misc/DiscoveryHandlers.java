package at.petrak.hexcasting.api.misc;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiFunction;
import net.minecraft.class_1657;
import net.minecraft.class_1799;

public class DiscoveryHandlers {
    private static final List<BiFunction<class_1657, String, class_1799>> DEBUG_DISCOVERER = new ArrayList<>();

    public static class_1799 findDebugItem(class_1657 player, String type) {
        for (var discoverer : DEBUG_DISCOVERER) {
            var stack = discoverer.apply(player, type);
            if (!stack.method_7960()) {
                return stack;
            }
        }
        return class_1799.field_8037;
    }

    public static void addDebugItemDiscoverer(BiFunction<class_1657, String, class_1799> discoverer) {
        DEBUG_DISCOVERER.add(discoverer);
    }
}
