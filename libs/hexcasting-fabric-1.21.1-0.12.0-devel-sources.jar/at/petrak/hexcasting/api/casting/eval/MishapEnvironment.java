package at.petrak.hexcasting.api.casting.eval;

import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import org.jetbrains.annotations.Nullable;

/**
 * Kinda like {@link CastingEnvironment} but for executing mishaps.
 * <p>
 * To avoid horrible O(mn) scope problems we offer a set of stock bad effects.
 * The player is exposed nullably if you like though.
 */
public abstract class MishapEnvironment {
    @Nullable
    protected final class_3222 caster;
    protected final class_3218 world;

    protected MishapEnvironment(class_3218 world, @Nullable class_3222 caster) {
        this.caster = caster;
        this.world = world;
    }

    public abstract void yeetHeldItemsTowards(class_243 targetPos);

    public abstract void dropHeldItems();

    public abstract void drown();

    public abstract void damage(float healthProportion);

    public abstract void removeXp(int amount);

    public abstract void blind(int ticks);

    public abstract void nauseate(int ticks);

    protected void yeetItem(class_1799 stack, class_243 srcPos, class_243 delta) {
        var entity = new class_1542(
            this.world,
            srcPos.field_1352, srcPos.field_1351, srcPos.field_1350,
            stack,
            delta.field_1352 + (Math.random() - 0.5) * 0.1,
            delta.field_1351 + (Math.random() - 0.5) * 0.1,
            delta.field_1350 + (Math.random() - 0.5) * 0.1
        );
        entity.method_6982(40);
        this.world.method_18768(entity);
    }
}
