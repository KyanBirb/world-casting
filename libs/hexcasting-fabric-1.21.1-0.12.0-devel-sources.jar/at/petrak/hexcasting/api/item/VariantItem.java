package at.petrak.hexcasting.api.item;

import at.petrak.hexcasting.common.lib.HexDataComponents;
import net.minecraft.class_1799;

/**
 * Items that have multiple different otherwise identical visual variants can implement this interface.
 * <p>
 * On both the Forge and Fabric sides, the registry will be scanned for all items which implement this interface,
 * and the appropriate cap/CC will be attached.
 */
public interface VariantItem {

    int numVariants();

    default int getVariant(class_1799 stack) {
        var variant = stack.method_57824(HexDataComponents.ITEM_VARIANT);
        return variant != null ? variant : 0;
    }

    default void setVariant(class_1799 stack, int variant) {
        stack.method_57379(HexDataComponents.ITEM_VARIANT, clampVariant(variant));
    }

    default int clampVariant(int variant) {
        if (variant < 0)
            return 0;
        if (variant >= numVariants())
            return numVariants() - 1;
        return variant;
    }
}
