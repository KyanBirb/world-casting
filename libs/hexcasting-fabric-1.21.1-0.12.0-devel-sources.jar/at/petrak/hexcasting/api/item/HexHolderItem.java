package at.petrak.hexcasting.api.item;

import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.pigment.FrozenPigment;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_3218;

/**
 * Items which can cast a packaged Hex can implement this interface.
 * <p>
 * On both the Forge and Fabric sides, the registry will be scanned for all items which implement this interface,
 * and the appropriate cap/CC will be attached.
 */
@ApiStatus.OverrideOnly
public interface HexHolderItem extends MediaHolderItem {

    boolean canDrawMediaFromInventory(class_1799 stack);

    boolean hasHex(class_1799 stack);

    @Nullable
    List<Iota> getHex(class_1799 stack, class_3218 level);

    void writeHex(class_1799 stack, List<Iota> program, @Nullable FrozenPigment pigment, long media);

    void clearHex(class_1799 stack);

    @Nullable FrozenPigment getPigment(class_1799 stack);
}
