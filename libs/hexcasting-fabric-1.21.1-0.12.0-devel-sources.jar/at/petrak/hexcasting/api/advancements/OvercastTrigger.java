package at.petrak.hexcasting.api.advancements;

import at.petrak.hexcasting.api.mod.HexConfig;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import net.minecraft.class_2048;
import net.minecraft.class_2096;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5258;

// https://github.com/TelepathicGrunt/Bumblezone/blob/latest-released/src/main/java/com/telepathicgrunt/the_bumblezone/advancements/CleanupStickyHoneyResidueTrigger.java
// https://github.com/VazkiiMods/Botania/blob/b8706e2e0bba20f67f1e103559a4ce39d63d48f9/src/main/java/vazkii/botania/common/advancements/CorporeaRequestTrigger.java

public class OvercastTrigger extends class_4558<OvercastTrigger.Instance> {
    private static final class_2960 ID = class_2960.method_60655("hexcasting", "overcast");

    @Override
    public Codec<Instance> method_54937() {
        return Instance.CODEC;
    }

    public void trigger(class_3222 player, int mediaGenerated) {
        super.method_22510(player, inst -> {
            var mediaToHealth = HexConfig.common().mediaToHealthRate();
            var healthUsed = mediaGenerated / mediaToHealth;
            return inst.test(mediaGenerated, healthUsed / player.method_6063(), player.method_6032());
        });
    }

    public static record Instance(
            Optional<class_5258> player,
            class_2096.class_2100 mediaGenerated,
            // This is the *proporttion* of the health bar.
            class_2096.class_2099 healthUsed,
            // DID YOU KNOW THERES ONE TO CHECK THE WORLD TIME, BUT NOT THE HEALTH!?
            class_2096.class_2099 healthLeft
            // DID YOU KNOW THERE'S ONE TO CHECK THE FUCKING C A T T Y P E BUT NOT THE HEALTH
    ) implements class_4558.class_8788 {
        public static final Codec<Instance> CODEC = RecordCodecBuilder.create(
                inst -> inst.group(
                                class_2048.field_47250.optionalFieldOf("player").forGetter(Instance::comp_2029),
                                class_2096.class_2100.field_45763.fieldOf("media_generated").forGetter(Instance::mediaGenerated),
                                class_2096.class_2099.field_45762.fieldOf("health_used").forGetter(Instance::healthUsed),
                                // HEY KIDS DID YOYU KNOW THERE'S NOT A CRITERIA FOR HOW MUCH ***HEALTH*** AN ENTITY HAS
                                class_2096.class_2099.field_45762.fieldOf("mojang_i_am_begging_and_crying_please_add_an_entity_health_criterion").forGetter(Instance::healthLeft)
                        )
                        .apply(inst, Instance::new)
        );

        private boolean test(int mediaGeneratedIn, double healthUsedIn, float healthLeftIn) {
            return this.mediaGenerated.method_9054(mediaGeneratedIn)
                && this.healthUsed.method_9047(healthUsedIn)
                // DID YOU KNOW ALL THE ENEITYT PREDICATES ARE HARD-CODED AND YOU CANT MAKE NEW ONES
                && this.healthLeft.method_9047(healthLeftIn);
        }
    }
}
