package at.petrak.hexcasting.api.casting.mishaps

import at.petrak.hexcasting.api.casting.eval.CastingEnvironment
import at.petrak.hexcasting.api.casting.iota.EntityIota
import at.petrak.hexcasting.api.casting.iota.Iota
import at.petrak.hexcasting.api.pigment.FrozenPigment
import at.petrak.hexcasting.api.utils.TreeList
import at.petrak.hexcasting.api.utils.aqua
import net.minecraft.ChatFormatting
import net.minecraft.network.chat.Component
import net.minecraft.world.item.DyeColor
import java.util.*

class MishapEntityNotFound(val entityId: UUID, val entityName: Component?) : Mishap() {
    override fun accentColor(ctx: CastingEnvironment, errorCtx: Context): FrozenPigment =
        dyeColor(DyeColor.BROWN)

    override fun execute(env: CastingEnvironment, errorCtx: Context, stack: TreeList<Iota>): TreeList<Iota> {
        env.mishapEnvironment.nauseate(5 * 20)
        return stack
    }

    override fun errorMessage(ctx: CastingEnvironment, errorCtx: Context) =
        error("entity_not_found", (entityName?.plainCopy() ?: Component.literal(entityId.toString())).aqua)

    companion object {
        @JvmStatic
        fun of(entityIota: EntityIota): MishapEntityNotFound {
            return MishapEntityNotFound(entityIota.entityId, entityIota.entityName)
        }
    }
}
