package at.petrak.hexcasting.interop.emi;

import at.petrak.hexcasting.common.lib.HexBlocks;
import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.api.recipe.EmiRecipeCategory;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.widget.WidgetHolder;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.class_2960;
import net.minecraft.class_3489;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class EmiEdifyRecipe implements EmiRecipe {
    private static final class_2960 OVERLAY = modLoc("textures/gui/edify_recipe.png");

    private final EmiIngredient saplings;
    private final EmiIngredient leaves;
    private final EmiIngredient log;

    public EmiEdifyRecipe() {
        this.saplings = EmiIngredient.of(class_3489.field_15528);
        this.leaves = EmiIngredient.of(List.of(
            EmiStack.of(HexBlocks.AMETHYST_EDIFIED_LEAVES.get()),
            EmiStack.of(HexBlocks.AVENTURINE_EDIFIED_LEAVES.get()),
            EmiStack.of(HexBlocks.CITRINE_EDIFIED_LEAVES.get())
        ));
        this.log = EmiIngredient.of(List.of(
                EmiStack.of(HexBlocks.EDIFIED_LOG.get()),
                EmiStack.of(HexBlocks.EDIFIED_LOG_AMETHYST.get()),
                EmiStack.of(HexBlocks.EDIFIED_LOG_AVENTURINE.get()),
                EmiStack.of(HexBlocks.EDIFIED_LOG_CITRINE.get())
//                EmiStack.of(HexBlocks.EDIFIED_LOG_PURPLE.get())
        ));
    }

    @Override
    public EmiRecipeCategory getCategory() {
        return HexEMIPlugin.EDIFY;
    }

    @Override
    public @Nullable class_2960 getId() {
        return modLoc("/edify");
    }

    @Override
    public List<EmiIngredient> getInputs() {
        return List.of(saplings);
    }

    @Override
    public List<EmiStack> getOutputs() {
        return Stream.concat(leaves.getEmiStacks().stream(), log.getEmiStacks().stream()).collect(Collectors.toList());
    }

    @Override
    public int getDisplayWidth() {
        return 79;
    }

    @Override
    public int getDisplayHeight() {
        return 61;
    }

    @Override
    public boolean supportsRecipeTree() {
        return false;
    }

    @Override
    public void addWidgets(WidgetHolder widgets) {
        widgets.addTexture(OVERLAY, 0, 0, getDisplayWidth(), getDisplayHeight(), 0, 0, getDisplayWidth(), getDisplayHeight(), 128, 128);
        widgets.addSlot(saplings, 11, 21).drawBack(false).customBackground(null, 0, 0, 19, 19);
        widgets.addGeneratedSlot(r -> {
            var stacks = leaves.getEmiStacks();
            return stacks.get(r.nextInt(stacks.size()));
        }, 0, 50, 9).drawBack(false).recipeContext(this).customBackground(null, 0, 0, 19, 19);
        widgets.addSlot(log, 50, 34).drawBack(false).recipeContext(this).customBackground(null, 0, 0, 19, 19);
    }
}
