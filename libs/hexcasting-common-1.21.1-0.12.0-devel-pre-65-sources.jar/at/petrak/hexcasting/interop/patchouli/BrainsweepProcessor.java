package at.petrak.hexcasting.interop.patchouli;

import at.petrak.hexcasting.common.recipe.BrainsweepRecipe;
import at.petrak.hexcasting.common.recipe.HexRecipeStuffRegistry;
import org.jetbrains.annotations.Nullable;
import vazkii.patchouli.api.IComponentProcessor;
import vazkii.patchouli.api.IVariable;
import vazkii.patchouli.api.IVariableProvider;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_7923;

public class BrainsweepProcessor implements IComponentProcessor {
	private BrainsweepRecipe recipe;
	@Nullable
	private List<IVariable> exampleEntityList;

	@Override
	public void setup(class_1937 level, IVariableProvider vars) {
		var id = class_2960.method_60654(vars.get("recipe", level.method_30349()).asString());

		var recman = level.method_8433();
		var brainsweepings = recman.method_30027(HexRecipeStuffRegistry.BRAINSWEEP_TYPE.get());
		for (var poisonApples : brainsweepings) {
			if (poisonApples.comp_1932().equals(id)) {
				this.recipe = poisonApples.comp_1933();
				break;
			}
		}
	}

	@Override
	public IVariable process(class_1937 level, String key) {
		if (this.recipe == null) {
			return null;
		}

		switch (key) {
			case "header" -> {
				return IVariable.from(this.recipe.result().method_26204().method_9518(), level.method_30349());
			}
			case "input" -> {
				var inputStacks = this.recipe.blockIn().getDisplayedStacks();
				return IVariable.from(inputStacks.toArray(new class_1799[0]), level.method_30349());
			}
			case "result" -> {
				return IVariable.from(new class_1799(this.recipe.result().method_26204()), level.method_30349());
			}

			case "entity" -> {
				if (this.exampleEntityList == null) {
					var entities = this.recipe.entityIn().exampleEntities(class_310.method_1551().field_1687);
					if (entities.isEmpty()) {
						// oh dear
						return null;
					}

					this.exampleEntityList = entities.stream().map(entity -> {
						var bob = new StringBuilder();
						bob.append(class_7923.field_41177.method_10221(entity.method_5864()));

						var tag = new class_2487();
						entity.method_5662(tag);
						bob.append(tag.toString());
						return IVariable.wrap(bob.toString(), level.method_30349());
					}).toList();
				}

				//return IVariable.wrapList(this.exampleEntityList);
				// patchouli does not currently support cycling entity displays
				// https://github.com/VazkiiMods/Patchouli/issues/852
				return this.exampleEntityList.get(0);
			}
			case "entityTooltip" -> {
				class_310 mc = class_310.method_1551();
				return IVariable.wrapList(this.recipe.entityIn()
					.getTooltip(mc.field_1690.field_1827)
					.stream()
					.map(v -> IVariable.from(v, level.method_30349()))
					.toList(), level.method_30349());
			}
			case "mediaCost" -> {
				List<class_1799> stacks = PatchouliUtils.mediaItems(this.recipe.mediaCost());
				return IVariable.wrapList(stacks.stream().map(s -> IVariable.from(s, level.method_30349())).toList(), level.method_30349());
			}
			default -> {
				return null;
			}
		}
	}
}
