package at.petrak.hexcasting.interop.patchouli;

import at.petrak.hexcasting.api.misc.MediaConstants;
import at.petrak.hexcasting.common.items.magic.ItemMediaBattery;
import at.petrak.hexcasting.common.lib.HexItems;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3956;
import net.minecraft.class_7225;
import net.minecraft.class_8786;
import net.minecraft.class_9695;
import net.minecraft.world.item.crafting.*;
import vazkii.patchouli.api.IVariable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * > no this is a "literally copy these files/parts of file into your mod"
 * > we should put this in patchy but lol
 * > lazy
 * -- Hubry Vazcord
 */
public class PatchouliUtils {
    @SuppressWarnings("unchecked")
    public static <T extends class_1860<I>, I extends class_9695> T getRecipe(class_3956<T> type, class_2960 id) {
        // PageDoubleRecipeRegistry
        if (class_310.method_1551().field_1687 == null) {
            return null;
        } else {
            var manager = class_310.method_1551().field_1687.method_8433();

            return (T) manager.method_8130(id)
                .map(class_8786::comp_1933)
                .filter((recipe) -> recipe.method_17716() == type).orElse(null);
        }
    }

    /**
     * Combines the ingredients, returning the first matching stack of each, then the second stack of each, etc.
     * looping back ingredients that run out of matched stacks, until the ingredients reach the length
     * of the longest ingredient in the recipe set.
     *
     * @param ingredients           List of ingredients in the specific slot
     * @param longestIngredientSize Longest ingredient in the entire recipe
     * @return Serialized Patchouli ingredient string
     */
    public static IVariable interweaveIngredients(List<class_1856> ingredients, int longestIngredientSize, class_7225.class_7226.Provider registries) {
        if (ingredients.size() == 1) {
            return IVariable.wrapList(Arrays.stream(ingredients.get(0).method_8105())
                    .map(v -> IVariable.from(v, registries))
                    .collect(Collectors.toList()), registries);
        }

        class_1799[] empty = {class_1799.field_8037};
        List<class_1799[]> stacks = new ArrayList<>();
        for (class_1856 ingredient : ingredients) {
            if (ingredient != null && !ingredient.method_8103()) {
                stacks.add(ingredient.method_8105());
            } else {
                stacks.add(empty);
            }
        }
        List<IVariable> list = new ArrayList<>(stacks.size() * longestIngredientSize);
        for (int i = 0; i < longestIngredientSize; i++) {
            for (class_1799[] stack : stacks) {
                list.add(IVariable.from(stack[i % stack.length], registries));
            }
        }
        return IVariable.wrapList(list, registries);
    }

    /**
     * Overload of the method above that uses the provided list's longest ingredient size.
     */
    public static IVariable interweaveIngredients(List<class_1856> ingredients, class_7225.class_7226.Provider registries) {
        return interweaveIngredients(ingredients,
            ingredients.stream().mapToInt(ingr -> ingr.method_8105().length).max().orElse(1), registries
        );
    }

    /**
     * @param mediaCost The amount of media to represent
     * @return A list of ItemStacks in dust, shards, and charged that equal the given amount of media. If the amount cannot be represented in an integer multiple of dust, falls back to a phial.
     */
    public static List<class_1799> mediaItems(long mediaCost) {
        record ItemCost(class_1792 item, int cost) {
            public boolean dividesEvenly (int dividend) {
                return dividend % cost == 0;
            }
        }
        ItemCost[] costs = {
                new ItemCost(HexItems.AMETHYST_DUST.get(), (int)MediaConstants.DUST_UNIT),
                new ItemCost(class_1802.field_27063, (int)MediaConstants.SHARD_UNIT),
                new ItemCost(HexItems.CHARGED_AMETHYST.get(), (int)MediaConstants.CRYSTAL_UNIT),
        };

        // get evenly divisible ItemStacks
        List<class_1799> validItemStacks = Arrays.stream(costs)
                .filter(itemCost -> itemCost.dividesEvenly((int)mediaCost))
                .map(validItemCost -> new class_1799(validItemCost.item, (int)mediaCost / validItemCost.cost))
                .toList();

        if (!validItemStacks.isEmpty()) return validItemStacks;

        return List.of(ItemMediaBattery.withMedia(new class_1799(HexItems.BATTERY.get()), mediaCost, mediaCost));
    }
}
