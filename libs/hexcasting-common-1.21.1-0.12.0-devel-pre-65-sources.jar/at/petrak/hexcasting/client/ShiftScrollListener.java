package at.petrak.hexcasting.client;

import at.petrak.hexcasting.api.mod.HexConfig;
import at.petrak.hexcasting.common.items.storage.ItemSpellbook;
import at.petrak.hexcasting.common.lib.HexDataComponents;
import at.petrak.hexcasting.common.lib.HexItemComponents;
import at.petrak.hexcasting.common.lib.HexItems;
import at.petrak.hexcasting.common.msgs.MsgShiftScrollC2S;
import at.petrak.hexcasting.xplat.IClientXplatAbstractions;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_746;

public class ShiftScrollListener {
    private static double mainHandDelta = 0;
    private static double offHandDelta = 0;

    public static boolean onScrollInGameplay(double delta) {
        if (class_310.method_1551().field_1755 != null) {
            return false;
        }

        if (HexConfig.client().disableInworldScrolling()) return false;

        return onScroll(delta, true);
    }

    public static boolean onScroll(double delta, boolean needsSneaking) {
        return onScroll(delta, needsSneaking, true);
    }

    public static boolean onScroll(double delta, boolean needsSneaking, boolean allowInverting) {
        class_746 player = class_310.method_1551().field_1724;
        // not .isCrouching! that fails for players who are not on the ground
        // yes, this does work if you remap your sneak key
        if (player != null && (player.method_5715() || !needsSneaking)) {
            // Spectators shouldn't interact with items!
            if (player.method_7325()) {
                return false;
            }

            if (isScrollableStack(player.method_6047())) {
                mainHandDelta += delta * getScrollModifier(player.method_6047(), allowInverting);
                return true;
            } else if (isScrollableStack(player.method_6079())) {
                offHandDelta += delta * getScrollModifier(player.method_6079(), allowInverting);
                return true;
            }
        }

        return false;
    }

    public static void clientTickEnd() {
        if (mainHandDelta != 0 || offHandDelta != 0) {
            IClientXplatAbstractions.INSTANCE.sendPacketToServer(
                new MsgShiftScrollC2S(mainHandDelta, offHandDelta, class_310.method_1551().field_1690.field_1867.method_1434())
            );
            mainHandDelta = 0;
            offHandDelta = 0;
        }
    }

    private static boolean isScrollableStack(class_1799 stack) {
        return stack.method_57826(HexDataComponents.SELECTED_SPELLBOOK_PAGE.get()) || stack.method_7909() == HexItems.ABACUS;
    }

    private static double getScrollModifier(class_1799 stack, boolean allowInverting) {
        if (!allowInverting) return 1;

        if (stack.method_7909() == HexItems.ABACUS) {
            return HexConfig.client().invertAbacusScrollDirection() ? -1 : 1;
        } else if (stack.method_57826(HexDataComponents.SELECTED_SPELLBOOK_PAGE.get())) {
            return HexConfig.client().invertSpellbookScrollDirection() ? -1 : 1;
        } else {
            return 1;
        }
    }
}
